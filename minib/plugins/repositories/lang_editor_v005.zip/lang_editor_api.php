<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Lang Editor" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();
require_once 'lang/loader.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'get_plugins':
        getPlugins();
        break;
        
    case 'get_plugin_languages':
        getPluginLanguages();
        break;
        
    case 'save_language':
        saveLanguage();
        break;
        
    case 'save_plugin_language':
        savePluginLanguage();
        break;
        
    case 'save_as':
        saveAsLanguage();
        break;
        
    case 'save_plugin_as':
        savePluginAsLanguage();
        break;
        
    case 'create_language':
        createLanguage();
        break;
        
    case 'create_plugin_language':
        createPluginLanguage();
        break;
        
    case 'upload_language':
        uploadLanguage();
        break;
        
    case 'upload_plugin_language':
        uploadPluginLanguage();
        break;
        
    case 'upload_icon':
        uploadIcon();
        break;
        
    case 'upload_plugin_icon':
        uploadPluginIcon();
        break;
        
    case 'update_settings':
        updateSettings();
        break;
        
    case 'update_plugin_settings':
        updatePluginSettings();
        break;
        
    case 'download_language':
        downloadLanguage();
        break;
        
    case 'download_plugin_language':
        downloadPluginLanguage();
        break;
        
    case 'delete_language':
        deleteLanguage();
        break;
        
    case 'delete_plugin_language':
        deletePluginLanguage();
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Unknown action']);
}

function getPlugins() {
    $plugins_dir = dirname(dirname(dirname(__FILE__))) . '/plugins/';
    $plugins = [];
    
    if (is_dir($plugins_dir)) {
        $items = scandir($plugins_dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            
            if ($item === 'menu') continue;
            
            $plugin_path = $plugins_dir . $item;
            if (is_dir($plugin_path)) {
                $lang_path = $plugin_path . '/lang/';
                $has_lang = is_dir($lang_path);
                
                $lang_count = 0;
                if ($has_lang) {
                    $files = scandir($lang_path);
                    foreach ($files as $file) {
                        if ($file === 'loader.php' || $file === '.' || $file === '..') continue;
                        if (preg_match('/^[A-Za-z]{2}\.php$/', $file)) {
                            $lang_count++;
                        }
                    }
                }
                
                $plugins[] = [
                    'name' => $item,
                    'path' => $plugin_path,
                    'has_lang' => $has_lang,
                    'lang_count' => $lang_count
                ];
            }
        }
    }
    
    echo json_encode(['success' => true, 'plugins' => $plugins]);
}

function getPluginLanguages() {
    $plugin = $_GET['plugin'] ?? '';
    
    if (empty($plugin)) {
		global $lang96;
        echo json_encode(['success' => false, 'error' => $lang96]);
        return;
    }
    
    if ($plugin === 'menu') {
		global $lang97;
        echo json_encode(['success' => false, 'error' => $lang97]);
        return;
    }
    
    $lang_dir = dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin . '/lang/';
    $languages = [];
    
    if (!is_dir($lang_dir)) {
		global $lang98;
        echo json_encode(['success' => false, 'error' => $lang98]);
        return;
    }
    
    $files = scandir($lang_dir);
    foreach ($files as $file) {
        if ($file === 'loader.php' || $file === '.' || $file === '..') continue;
        
        if (preg_match('/^([A-Za-z]{2})\.php$/', $file, $matches)) {
            $code = $matches[1];
            $content = file_get_contents($lang_dir . $file);
            
            $name = $code;
            $icon = '';
            $author = '';
            $version = '';
            $date_update = '';
            
            if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) {
                $name = $m[1];
            }
            if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) {
                $icon = $m[1];
            }
            if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) {
                $author = $m[1];
            }
            if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) {
                $version = $m[1];
            }
            if (preg_match('/\$LANG_DATE_UPDATE\s*=\s*"([^"]+)"/', $content, $m)) {
                $date_update = $m[1];
            }
            
            preg_match_all('/\$lang\d+\s*=/', $content, $var_count);
            
            $languages[] = [
                'code' => $code,
                'name' => $name,
                'icon' => $icon,
                'author' => $author,
                'version' => $version,
                'date_update' => $date_update,
                'file' => $file,
                'size' => filesize($lang_dir . $file),
                'modified' => date('Y-m-d H:i:s', filemtime($lang_dir . $file)),
                'variables' => count($var_count[0])
            ];
        }
    }
    
    usort($languages, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    
    echo json_encode(['success' => true, 'languages' => $languages]);
}

function getLanguageFilePath($code, $plugin = null) {
    if ($plugin && $plugin === 'menu') {
        return null;
    }
    
    if ($plugin) {
        return dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin . '/lang/' . $code . '.php';
    }
    return dirname(dirname(dirname(__FILE__))) . '/lang/' . $code . '.php';
}

function getLanguageDirPath($plugin = null) {
    if ($plugin && $plugin === 'menu') {
        return null;
    }
    
    if ($plugin) {
        return dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin . '/lang/';
    }
    return dirname(dirname(dirname(__FILE__))) . '/lang/';
}

function saveLanguage() {
    $code = $_POST['code'] ?? '';
    $variables = json_decode($_POST['variables'] ?? '[]', true);
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($code)) {
		global $lang99;
        echo json_encode(['success' => false, 'error' => $lang99]);
        return;
    }
    
    $lang_file = getLanguageFilePath($code, $plugin);
    
    if (!file_exists($lang_file)) {
		global $lang100;
        echo json_encode(['success' => false, 'error' => $lang100]);
        return;
    }
    
    $content = file_get_contents($lang_file);
    
    $metadata = [];
    if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) $metadata['name'] = $m[1];
    if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) $metadata['icon'] = $m[1];
    if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) $metadata['author'] = $m[1];
    if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) $metadata['version'] = $m[1];
    
    $newContent = '<?php' . "\n\n";
    $newContent .= '$LANG_NAME = "' . addslashes($metadata['name'] ?? '') . "\";\n";
    $newContent .= '$LANG_ICON = "' . addslashes($metadata['icon'] ?? '') . "\";\n";
    $newContent .= '$LANG_AUTHOR = "' . addslashes($metadata['author'] ?? 'Mini-B') . "\";\n";
    $newContent .= '$LANG_DATE_UPDATE = "' . date('Y-m-d H:i:s') . "\";\n";
    $newContent .= '$LANG_VERSION = "' . addslashes($metadata['version'] ?? '1.0.0') . "\";\n";
    $newContent .= '//##############################################' . "\n\n";
    
    $sections = [];
    $current_section = '';
    $lines = explode("\n", $content);
    foreach ($lines as $line) {
        if (preg_match('/\/\/\s*#########\s*([^#]+)\s*##########/', $line, $matches)) {
            $current_section = trim($matches[1]);
        }
        if (preg_match('/\$lang(\d+)\s*=/', $line) && !empty($current_section)) {
            $sections[$current_section] = true;
        }
    }
    
    if (empty($sections)) {
        $sections['index.php'] = true;
    }
    
    foreach ($sections as $section => $value) {
        $newContent .= '// ######### ' . $section . ' ##########' . "\n";
        foreach ($variables as $var) {
            $newContent .= '$' . $var['key'] . ' = "' . addslashes($var['value']) . "\";\n";
        }
        $newContent .= "\n";
    }
    
    if (empty($sections)) {
        foreach ($variables as $var) {
            $newContent .= '$' . $var['key'] . ' = "' . addslashes($var['value']) . "\";\n";
        }
    }
    
    $newContent .= "\n?>";
    
    if (file_put_contents($lang_file, $newContent)) {
        echo json_encode(['success' => true]);
    } else {
		global $lang101;
        echo json_encode(['success' => false, 'error' => $lang101]);
    }
}

function savePluginLanguage() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    saveLanguage();
}

function saveAsLanguage() {
    $source_code = $_POST['source_code'] ?? '';
    $new_code = $_POST['new_code'] ?? '';
    $new_name = $_POST['new_name'] ?? '';
    $new_author = $_POST['new_author'] ?? 'Mini-B';
    $new_version = $_POST['new_version'] ?? '1.0.0';
    $variables = json_decode($_POST['variables'] ?? '[]', true);
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($source_code) || empty($new_code) || empty($new_name)) {
		global $lang102;
        echo json_encode(['success' => false, 'error' => $lang102]);
        return;
    }
    
    $new_code = ucfirst(strtolower($new_code));
    
    $new_file = getLanguageFilePath($new_code, $plugin);
    
    if (file_exists($new_file)) {
		global $lang103;
        echo json_encode(['success' => false, 'error' => $lang103 . $new_code . '.php']);
        return;
    }
    
    $newContent = '<?php' . "\n\n";
    $newContent .= '$LANG_NAME = "' . addslashes($new_name) . "\";\n";
    $newContent .= '$LANG_ICON = "' . addslashes($_POST['new_icon'] ?? '') . "\";\n";
    $newContent .= '$LANG_AUTHOR = "' . addslashes($new_author) . "\";\n";
    $newContent .= '$LANG_DATE_UPDATE = "' . date('Y-m-d H:i:s') . "\";\n";
    $newContent .= '$LANG_VERSION = "' . addslashes($new_version) . "\";\n";
    $newContent .= '//##############################################' . "\n\n";
    $newContent .= '// ######### index.php ##########' . "\n";
    
    foreach ($variables as $var) {
        $newContent .= '$' . $var['key'] . ' = "' . addslashes($var['value']) . "\";\n";
    }
    
    $newContent .= "\n?>";
    
    if (file_put_contents($new_file, $newContent)) {
        echo json_encode(['success' => true, 'code' => $new_code]);
    } else {
		global $lang104;
        echo json_encode(['success' => false, 'error' => $lang104]);
    }
}

function savePluginAsLanguage() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    saveAsLanguage();
}

function createLanguage() {
    $code = $_POST['code'] ?? '';
    $name = $_POST['name'] ?? '';
    $author = $_POST['author'] ?? 'Mini-B';
    $version = $_POST['version'] ?? '1.0.0';
    $icon = $_POST['icon'] ?? '';
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($code) || empty($name)) {
        global $lang105;
        echo json_encode(['success' => false, 'error' => $lang105]);
        return;
    }
    
    $code = ucfirst(strtolower($code));
    
    $lang_dir = getLanguageDirPath($plugin);
    if (!is_dir($lang_dir)) {
        mkdir($lang_dir, 0755, true);
    }
    
    if ($plugin !== null) {
        $icon_dir = $lang_dir . 'icon/';
        if (!is_dir($icon_dir)) {
            mkdir($icon_dir, 0755, true);
        }
    }
    
    $new_file = $lang_dir . $code . '.php';
    
    if (file_exists($new_file)) {
        global $lang106;
        echo json_encode(['success' => false, 'error' => $lang106 . $code . '.php']);
        return;
    }
    
    $content = '<?php' . "\n\n";
    $content .= '$LANG_NAME = "' . addslashes($name) . "\";\n";
    $content .= '$LANG_ICON = "' . addslashes($icon) . "\";\n";
    $content .= '$LANG_AUTHOR = "' . addslashes($author) . "\";\n";
    $content .= '$LANG_DATE_UPDATE = "' . date('Y-m-d H:i:s') . "\";\n";
    $content .= '$LANG_VERSION = "' . addslashes($version) . "\";\n";
    $content .= '//##############################################' . "\n\n";
    $content .= '// ######### index.php ##########' . "\n";
    $content .= '$lang1 = "";' . "\n";
    $content .= '$lang2 = "";' . "\n";
    $content .= '$lang3 = "";' . "\n\n";
    $content .= '?>';
    
    if (file_put_contents($new_file, $content)) {
        if ($plugin !== null) {
            $loader_file = $lang_dir . 'loader.php';
            if (!file_exists($loader_file)) {
                $source_loader = 'lang/loader.php';
                if (file_exists($source_loader)) {
                    copy($source_loader, $loader_file);
                }
            }
        }
        
        echo json_encode(['success' => true, 'code' => $code]);
    } else {
        global $lang107;
        echo json_encode(['success' => false, 'error' => $lang107]);
    }
}

function createPluginLanguage() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    createLanguage();
}

function uploadLanguage() {
	global $lang108;
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => $lang108]);
        return;
    }
    
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $plugin = $_POST['plugin'] ?? null;
    
    if (!preg_match('/^[A-Za-z]{2}\.php$/', $filename)) {
		global $lang109;
        echo json_encode(['success' => false, 'error' => $lang109]);
        return;
    }
    
    $code = pathinfo($filename, PATHINFO_FILENAME);
    $normalized_code = ucfirst(strtolower($code));
    $normalized_filename = $normalized_code . '.php';
    
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    if (strtolower($ext) !== 'php') {
		global $lang110;
        echo json_encode(['success' => false, 'error' => $lang110]);
        return;
    }
    
    $target_dir = getLanguageDirPath($plugin);
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }
    
    $target_file = $target_dir . $normalized_filename;
    
    if (file_exists($target_file)) {
		global $lang111;
        echo json_encode(['success' => false, 'error' => $lang111 . $normalized_filename]);
        return;
    }
    
    $content = file_get_contents($file['tmp_name']);
    if (strpos($content, '<?php') === false) {
		global $lang112;
        echo json_encode(['success' => false, 'error' => $lang112]);
        return;
    }
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        echo json_encode(['success' => true]);
    } else {
		global $lang113;
        echo json_encode(['success' => false, 'error' => $lang113]);
    }
}

function uploadPluginLanguage() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    uploadLanguage();
}

function uploadIcon() {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
		global $lang114;
        echo json_encode(['success' => false, 'error' => $lang114]);
        return;
    }
    
    $code = $_POST['code'] ?? '';
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($code)) {
		global $lang115;
        echo json_encode(['success' => false, 'error' => $lang115]);
        return;
    }
    
    $file = $_FILES['file'];
    $allowed_types = ['image/png', 'image/jpeg', 'image/gif', 'image/svg+xml', 'image/webp'];
    $allowed_ext = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'];
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, $allowed_types)) {
		global $lang116;
        echo json_encode(['success' => false, 'error' => $lang116]);
        return;
    }
    
    if ($file['size'] > 2 * 1024 * 1024) {
		global $lang117;
        echo json_encode(['success' => false, 'error' => $lang117]);
        return;
    }
    
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    if (!in_array(strtolower($ext), $allowed_ext)) {
        $ext = 'png';
    }
    
    if ($plugin) {
        $icon_dir = dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin . '/lang/icon/';
        $icon_path = 'plugins/' . $plugin . '/lang/icon/' . $code . '.' . $ext;
    } else {
        $icon_dir = dirname(dirname(dirname(__FILE__))) . '/lang/icon/';
        $icon_path = 'lang/icon/' . $code . '.' . $ext;
    }
    
    if (!is_dir($icon_dir)) {
        mkdir($icon_dir, 0755, true);
    }
    
    $icon_filename = $code . '.' . $ext;
    $target_file = $icon_dir . $icon_filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        echo json_encode(['success' => true, 'icon_path' => $icon_path]);
    } else {
		global $lang118;
        echo json_encode(['success' => false, 'error' => $lang118]);
    }
}

function uploadPluginIcon() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    uploadIcon();
}

function updateSettings() {
    $code = $_POST['code'] ?? '';
    $name = $_POST['name'] ?? '';
    $author = $_POST['author'] ?? '';
    $version = $_POST['version'] ?? '';
    $icon = $_POST['icon'] ?? '';
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($code) || empty($name)) {
		global $lang119;
        echo json_encode(['success' => false, 'error' => $lang119]);
        return;
    }
    
    $lang_file = getLanguageFilePath($code, $plugin);
    
    if (!file_exists($lang_file)) {
		global $lang120;
        echo json_encode(['success' => false, 'error' => $lang120]);
        return;
    }
    
    $content = file_get_contents($lang_file);
    
    if (!empty($name)) {
        $content = preg_replace('/\$LANG_NAME\s*=\s*"[^"]*"/', '$LANG_NAME = "' . addslashes($name) . '"', $content);
    }
    if (!empty($author)) {
        $content = preg_replace('/\$LANG_AUTHOR\s*=\s*"[^"]*"/', '$LANG_AUTHOR = "' . addslashes($author) . '"', $content);
    }
    if (!empty($version)) {
        $content = preg_replace('/\$LANG_VERSION\s*=\s*"[^"]*"/', '$LANG_VERSION = "' . addslashes($version) . '"', $content);
    }
    
    $content = preg_replace('/\$LANG_ICON\s*=\s*"[^"]*"/', '$LANG_ICON = "' . addslashes($icon) . '"', $content);
    
    $content = preg_replace(
        '/\$LANG_DATE_UPDATE\s*=\s*"[^"]*"/',
        '$LANG_DATE_UPDATE = "' . date('Y-m-d H:i:s') . '"',
        $content
    );
    
    if (file_put_contents($lang_file, $content)) {
        echo json_encode(['success' => true]);
    } else {
		global $lang121;
        echo json_encode(['success' => false, 'error' => $lang121]);
    }
}

function updatePluginSettings() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    updateSettings();
}

function downloadLanguage() {
    $code = $_GET['code'] ?? '';
    $plugin = $_GET['plugin'] ?? null;
    
    if (empty($code)) {
        http_response_code(400);
		global $lang122;
        echo json_encode(['success' => false, 'error' => $lang122]);
        return;
    }
    
    $lang_file = getLanguageFilePath($code, $plugin);
    
    if (!file_exists($lang_file)) {
        http_response_code(404);
		global $lang123;
        echo json_encode(['success' => false, 'error' => $lang123]);
        return;
    }
    
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $code . '.php"');
    header('Content-Length: ' . filesize($lang_file));
    header('Cache-Control: no-cache');
    
    readfile($lang_file);
    exit();
}

function downloadPluginLanguage() {
    downloadLanguage();
}

function deleteLanguage() {
    $code = $_POST['code'] ?? '';
    $plugin = $_POST['plugin'] ?? null;
    
    if (empty($code)) {
		global $lang124;
        echo json_encode(['success' => false, 'error' => $lang124]);
        return;
    }
    
    if ($code === 'En' && !$plugin) {
		global $lang125;
        echo json_encode(['success' => false, 'error' => $lang125]);
        return;
    }
    
    $lang_file = getLanguageFilePath($code, $plugin);
    
    if (!file_exists($lang_file)) {
		global $lang126;
        echo json_encode(['success' => false, 'error' => $lang126]);
        return;
    }
    
    if ($plugin) {
        $icon_pattern = dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin . '/lang/icon/' . $code . '.*';
    } else {
        $icon_pattern = dirname(dirname(dirname(__FILE__))) . '/lang/icon/' . $code . '.*';
    }
    $icons = glob($icon_pattern);
    foreach ($icons as $icon) {
        @unlink($icon);
    }
    
    if (unlink($lang_file)) {
        echo json_encode(['success' => true]);
    } else {
		global $lang127;
        echo json_encode(['success' => false, 'error' => $lang127]);
    }
}

function deletePluginLanguage() {
    $_POST['plugin'] = $_POST['plugin'] ?? null;
    deleteLanguage();
}
?>