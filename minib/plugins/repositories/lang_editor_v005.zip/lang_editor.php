<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Lang Editor" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();

require_once 'lang/loader.php';
$menu = require_once dirname(dirname(dirname(__FILE__))) . '/menu.php';

$lang_dir = dirname(dirname(dirname(__FILE__))) . '/lang/';
$languages = [];

if (is_dir($lang_dir)) {
    $files = scandir($lang_dir);
    foreach ($files as $file) {
        if ($file === 'loader.php') continue;
        if (preg_match('/^([A-Za-z]+)\.php$/', $file, $matches)) {
            $code = $matches[1];
            $content = file_get_contents($lang_dir . $file);
            
            $name = $code;
            $icon = '';
            $author = '';
            $version = '';
            $date_update = '';
            
            if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) {
                $name = $m[1];
            }
            if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) {
                $icon = $m[1];
            }
            if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) {
                $author = $m[1];
            }
            if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) {
                $version = $m[1];
            }
            if (preg_match('/\$LANG_DATE_UPDATE\s*=\s*"([^"]+)"/', $content, $m)) {
                $date_update = $m[1];
            }
            
            preg_match_all('/\$lang\d+\s*=/', $content, $var_count);
            
            $languages[] = [
                'code' => $code,
                'name' => $name,
                'icon' => $icon,
                'author' => $author,
                'version' => $version,
                'date_update' => $date_update,
                'file' => $file,
                'size' => filesize($lang_dir . $file),
                'modified' => date('Y-m-d H:i:s', filemtime($lang_dir . $file)),
                'variables' => count($var_count[0])
            ];
        }
    }
}

usort($languages, function($a, $b) {
    return strcmp($a['name'], $b['name']);
});

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Language Editor - Mini-B</title>
    <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../css/loader.css">
    <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
	<script>
	window.lang = {
		<?php
		for ($i = 1; $i <= 100; $i++) {
			$var_name = "lang$i";
			if (isset($$var_name)) {
				echo "'$i': '" . addslashes($$var_name) . "',\n";
			}
		}
		?>
	};
	function __(num) {
		return window.lang[num] || 'lang'+num;
	}
	console.log('Language loaded');
	</script>
    <style>
        .main-content {
            margin-left: 260px;
            padding: 24px 32px;
            flex: 1;
        }
        .lang-card {
            transition: all 0.2s;
            cursor: pointer;
            border-left: 3px solid transparent;
        }
        .lang-card:hover {
            transform: translateX(3px);
            background: #f8f9fa;
        }
        .stats-badge {
            font-size: 11px;
            padding: 4px 8px;
            border-radius: 20px;
        }
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        .search-box i {
            position: absolute;
            left: 12px;
            top: 12px;
            color: #6c757d;
        }
        .search-box input {
            padding-left: 35px;
        }
        .card-actions {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
            display: flex;
            gap: 5px;
        }
        .card-actions .btn {
            padding: 4px 8px;
            font-size: 12px;
            margin-top: 0;
        }
        .lang-card {
            position: relative;
        }
        .lang-icon {
            width: 16px;
            height: 16px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 12px;
        }
        .lang-icon-placeholder {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
        }
        .preview-icon {
            max-width: 80px;
            max-height: 80px;
            border-radius: 12px;
            border: 1px solid #ddd;
            padding: 5px;
        }
        .icon-preview-area {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .nav-tabs .nav-link {
            color: #495057;
            font-weight: 500;
        }
        .nav-tabs .nav-link.active {
            color: #007aff;
            font-weight: 600;
        }
        .plugin-card {
            transition: all 0.2s;
            border-left: 3px solid transparent;
            cursor: default;
        }
        .plugin-card.has-lang {
            cursor: pointer;
        }
        .plugin-card.has-lang:hover {
            transform: translateX(3px);
            background: #f8f9fa;
            border-left-color: #007aff;
        }
        .plugin-card.no-lang {
            opacity: 0.6;
        }
        .plugin-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 24px;
            color: #6c757d;
        }
        .plugin-card.has-lang .plugin-icon {
            background: #e3f2fd;
            color: #007aff;
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div id="applePreloader" class="apple-preloader">
    <div class="apple-spinner"></div>
    <div class="apple-spinner-text"><?php echo $lang2; ?></div>
</div>

<div class="top-bar">
    <div class="top-bar-left">
        <h1><i class="fas fa-bucket"></i> Mini-B</h1>
    </div>
    <div class="top-bar-right">
        <text><i class="fas fa-language"></i> Language Editor</text>
        <div class="btn-group">
            <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item text-success" href="#" onclick="showCreateModal()"><i class="fa fa-plus me-2"></i> <?php echo $lang3; ?></a></li>
                <li><a class="dropdown-item text-primary" href="#" onclick="showUploadModal()"><i class="fas fa-upload me-2"></i> <?php echo $lang4; ?></a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-secondary" href="#" onclick="window.location.reload()"><i class="fas fa-sync-alt me-2"></i> <?php echo $lang5; ?></a></li>
            </ul>
        </div>
    </div>
</div>

<div class="app-container">
    <?php echo $menu; ?>
    
    <main class="main-content">
        <div id="alertContainer"></div>
        
        <ul class="nav nav-tabs mb-3" id="langTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="system-tab" data-bs-toggle="tab" data-bs-target="#system" type="button" role="tab">
                    <i class="fas fa-server"></i> <?php echo $lang6; ?>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="plugins-tab" data-bs-toggle="tab" data-bs-target="#plugins" type="button" role="tab">
                    <i class="fas fa-puzzle-piece"></i> <?php echo $lang7; ?>
                </button>
            </li>
        </ul>
        
        <div class="tab-content">
            <!-- System Languages Tab -->
            <div class="tab-pane fade show active" id="system" role="tabpanel">
                <div class="widget">
                    <div class="widget-body">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="searchLang" placeholder="<?php echo $lang1; ?>">
                        </div>
                        
                        <div class="row" id="languageList">
                            <?php foreach ($languages as $lang): ?>
                            <div class="col-md-6 col-lg-4 mb-3 lang-item" data-name="<?php echo strtolower($lang['name']); ?>" data-code="<?php echo strtolower($lang['code']); ?>">
                                <div class="card lang-card h-100">
                                    <div class="card-actions">
                                        <div class="btn-group">
                                        <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fas fa-cog"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item text-success" href="#" onclick="event.stopPropagation(); downloadLanguage('<?php echo $lang['code']; ?>')"><i class="fas fa-download me-2"></i> <?php echo $lang8; ?></a></li>
                                            <li><a class="dropdown-item text-info" href="#" onclick="event.stopPropagation(); showEditSettingsModal('<?php echo $lang['code']; ?>', '<?php echo addslashes($lang['name']); ?>', '<?php echo addslashes($lang['icon']); ?>', '<?php echo addslashes($lang['author']); ?>', '<?php echo addslashes($lang['version']); ?>')"><i class="fas fa-edit me-2"></i> <?php echo $lang9; ?></a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item text-danger" href="#" onclick="event.stopPropagation(); deleteLanguage('<?php echo $lang['code']; ?>', '<?php echo addslashes($lang['name']); ?>')"><i class="fas fa-trash me-2"></i> <?php echo $lang10; ?></a></li>
                                        </ul>
                                    </div>
                                    </div>
                                    <div class="card-body" onclick="window.location.href='edit.php?code=<?php echo $lang['code']; ?>'" style="cursor: pointer;">
                                        <div class="d-flex align-items-start">
                                            <?php if (!empty($lang['icon']) && file_exists(dirname(dirname(dirname(__FILE__))) . '/' . $lang['icon'])): ?>
                                                <img src="../../<?php echo $lang['icon']; ?>" class="lang-icon" alt="<?php echo htmlspecialchars($lang['name']); ?>" onerror="this.style.display='none'; this.nextSibling.style.display='flex';">
                                                <div class="lang-icon-placeholder" style="display: none;">
                                                    <i class="fas fa-language fa-2x text-muted"></i>
                                                </div>
                                            <?php else: ?>
                                                <div class="lang-icon-placeholder">
                                                    <i class="fas fa-language fa-2x text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div style="flex: 1;">
                                                <h5 class="card-title mb-1"><?php echo htmlspecialchars($lang['name']); ?></h5>
                                                <small class="text-muted"><?php echo $lang['code']; ?>.php</small>
                                            </div>
                                        </div>
                                        <div class="mt-3">
                                            <small class="text-muted">
                                                <i class="far fa-calendar-alt"></i> <?php echo $lang['modified']; ?>
                                            </small>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-database"></i> <?php echo round($lang['size'] / 1024, 2); ?> KB
                                            </small>
                                            <?php if (!empty($lang['version'])): ?>
                                                <br>
                                                <small class="text-muted">
                                                    <i class="fas fa-tag"></i> v<?php echo htmlspecialchars($lang['version']); ?>
                                                </small>
                                            <?php endif; ?>
                                            <div class="text-end">
                                                <span class="badge bg-secondary stats-badge">
                                                    <i class="fas fa-code"></i> <?php echo $lang['variables']; ?> <?php echo $lang11; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <?php if (empty($languages)): ?>
                        <div class="text-center text-muted py-5">
                            <i class="fas fa-folder-open fa-4x mb-3"></i>
                            <p><?php echo $lang12; ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Plugins Tab -->
            <div class="tab-pane fade" id="plugins" role="tabpanel">
                <div class="widget">
                    <div class="widget-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="search-box" style="flex: 1; margin-bottom: 0;">
                                <i class="fas fa-search"></i>
                                <input type="text" class="form-control" id="searchPlugin" placeholder="<?php echo $lang13; ?>">
                            </div>
                            <button class="btn btn-success btn-sm ms-2" onclick="window.location.reload()">
                                <i class="fas fa-sync-alt"></i> <?php echo $lang14; ?>
                            </button>
                        </div>
                        
                        <div class="row" id="pluginList">
                            <!-- Will be loaded by JavaScript -->
                            <div class="col-12 text-center py-5">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden"><?php echo $lang15; ?></span>
                                </div>
                                <p class="mt-2 text-muted"><?php echo $lang16; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Create Language Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="fas fa-plus"></i> <?php echo $lang17; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="createPlugin" value="">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang18; ?> *</label>
                    <input type="text" class="form-control" id="createLangCode" placeholder="e.g., De, Fr, Es" maxlength="2" style="text-transform: uppercase;">
                    <small class="text-muted"><?php echo $lang19; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang20; ?> *</label>
                    <input type="text" class="form-control" id="createLangName" placeholder="e.g., Deutsch, Français">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang21; ?></label>
                    <input type="text" class="form-control" id="createLangAuthor" value="Mini-B">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang22; ?></label>
                    <input type="text" class="form-control" id="createLangVersion" value="1.0.0">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang23; ?></label>
                    <input type="text" class="form-control" id="createLangIcon" placeholder="lang/icon/De.png">
                </div>
                <div id="createPluginInfo" class="alert alert-info" style="display: none;">
                    <i class="fas fa-puzzle-piece"></i> <?php echo $lang24; ?> <strong id="createPluginName"></strong>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang25; ?></button>
                <button type="button" class="btn btn-success" onclick="createLanguage()"><?php echo $lang26; ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Settings Modal -->
<div class="modal fade" id="editSettingsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-cog"></i> <?php echo $lang27; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editLangCode">
                <input type="hidden" id="editPlugin">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang28; ?> *</label>
                    <input type="text" class="form-control" id="editLangName" placeholder="Language Name">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang29; ?></label>
                    <input type="text" class="form-control" id="editLangAuthor" placeholder="Author">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang30; ?></label>
                    <input type="text" class="form-control" id="editLangVersion" placeholder="Version">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang31; ?></label>
                    <input type="text" class="form-control" id="editLangIcon" placeholder="lang/icon/De.png">
                    <small class="text-muted"><?php echo $lang32; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang33; ?></label>
                    <input type="file" class="form-control" id="editLangIconFile" accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp">
                    <small class="text-muted">PNG, JPG, GIF, SVG, WEBP (Max 2MB)</small>
                </div>
                <div class="icon-preview-area" id="iconPreviewArea">
                    <div id="currentIconPreview">
                        <i class="fas fa-image fa-2x text-muted"></i>
                        <p class="mb-0 small"><?php echo $lang34; ?></p>
                    </div>
                </div>
                <div id="editPluginInfo" class="alert alert-info mt-3" style="display: none;">
                    <i class="fas fa-puzzle-piece"></i> <?php echo $lang35; ?> <strong id="editPluginName"></strong>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang36; ?></button>
                <button type="button" class="btn btn-info" onclick="saveLanguageSettings()"><?php echo $lang37; ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-upload"></i> <?php echo $lang38; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="uploadPlugin" value="">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang39; ?></label>
                    <input type="file" class="form-control" id="uploadFile" accept=".php">
                    <small class="text-muted"><?php echo $lang40; ?> (e.g., De.php, Fr.php)</small>
                </div>
                <div id="uploadPreview" style="display: none;" class="mt-3">
                    <div class="alert alert-info">
                        <strong><i class="fas fa-info-circle"></i> <?php echo $lang41; ?></strong><br>
                        <?php echo $lang42; ?> <span id="previewName"></span><br>
                        <?php echo $lang43; ?> <span id="previewSize"></span>
                    </div>
                </div>
                <div id="uploadPluginInfo" class="alert alert-info mt-3" style="display: none;">
                    <i class="fas fa-puzzle-piece"></i> <?php echo $lang44; ?> <strong id="uploadPluginName"></strong>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang45; ?></button>
                <button type="button" class="btn btn-primary" onclick="uploadLanguage()"><?php echo $lang46; ?></button>
            </div>
        </div>
    </div>
</div>

<script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
<script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="../../js/loader.js"></script>
<script>
let currentIconPreview = null;
let currentPlugin = null;

$(document).ready(function() {
    $('#searchLang').on('keyup', function() {
        const search = $(this).val().toLowerCase();
        $('.lang-item').each(function() {
            const name = $(this).data('name');
            const code = $(this).data('code');
            if (name.includes(search) || code.includes(search)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    $('#searchPlugin').on('keyup', function() {
        const search = $(this).val().toLowerCase();
        $('.plugin-item').each(function() {
            const name = $(this).data('name');
            if (name.includes(search)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // File upload preview
    $('#uploadFile').on('change', function() {
        const file = this.files[0];
        if (file) {
            $('#previewName').text(file.name);
            $('#previewSize').text((file.size / 1024).toFixed(2) + ' KB');
            $('#uploadPreview').show();
        } else {
            $('#uploadPreview').hide();
        }
    });
    
    // Icon file preview
    $('#editLangIconFile').on('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#currentIconPreview').html(`
                    <img src="${e.target.result}" class="preview-icon" style="max-width: 80px; max-height: 80px;">
                    <p class="mb-0 small"><?php echo $lang47; ?></p>
                `);
            };
            reader.readAsDataURL(file);
        } else {
            restoreIconPreview();
        }
    });
    
    // Load plugins when tab is shown
    $('#plugins-tab').on('shown.bs.tab', function() {
        loadPlugins();
    });
    
    // Preload plugins if tab is active by default
    if ($('#plugins-tab').hasClass('active')) {
        loadPlugins();
    }
    
    setTimeout(() => $('#applePreloader').fadeOut(500), 500);
});

function loadPlugins() {
    $('#pluginList').html(`
        <div class="col-12 text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden"><?php echo $lang48; ?></span>
            </div>
            <p class="mt-2 text-muted"><?php echo $lang49; ?></p>
        </div>
    `);
    
    fetch('lang_editor_api.php?action=get_plugins')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderPlugins(data.plugins);
            } else {
                $('#pluginList').html(`
                    <div class="col-12">
                        <div class="alert alert-danger"><?php echo $lang50; ?> ${data.error}</div>
                    </div>
                `);
            }
        })
        .catch(error => {
            $('#pluginList').html(`
                <div class="col-12">
                    <div class="alert alert-danger"><?php echo $lang51; ?> ${error.message}</div>
                </div>
            `);
        });
}

function renderPlugins(plugins) {
    if (plugins.length === 0) {
        $('#pluginList').html(`
            <div class="col-12 text-center py-5">
                <i class="fas fa-folder-open fa-4x mb-3 text-muted"></i>
                <p class="text-muted"><?php echo $lang52; ?></p>
            </div>
        `);
        return;
    }
    
    let html = '';
    plugins.forEach(plugin => {
        const hasLang = plugin.has_lang;
        const langCount = plugin.lang_count;
        const iconColor = hasLang ? 'text-primary' : 'text-muted';
        const cardClass = hasLang ? 'has-lang' : 'no-lang';
        const clickAction = hasLang ? `onclick="window.location.href='plugin_edit.php?plugin=${encodeURIComponent(plugin.name)}'"` : '';
        const badgeClass = hasLang ? 'bg-success' : 'bg-secondary';
        const badgeText = hasLang ? `${langCount} languages` : 'No lang folder';
        
        html += `
            <div class="col-md-6 col-lg-4 mb-3 plugin-item" data-name="${plugin.name.toLowerCase()}">
                <div class="card plugin-card ${cardClass} h-100" ${clickAction}>
                    <div class="card-body">
                        <div class="d-flex align-items-start">
                            <div class="plugin-icon">
                                <i class="fas fa-puzzle-piece"></i>
                            </div>
                            <div style="flex: 1;">
                                <h5 class="card-title mb-1">${plugin.name}</h5>
                                <small class="text-muted">/plugins/${plugin.name}/</small>
                            </div>
                        </div>
                        <div class="mt-3">
                            <span class="badge ${badgeClass}">${badgeText}</span>
                            ${hasLang ? `
                                <span class="badge bg-info ms-1">
                                    <i class="fas fa-edit"></i> <?php echo $lang53; ?>
                                </span>
                            ` : `
                                <span class="badge bg-secondary ms-1">
                                    <i class="fas fa-ban"></i> <?php echo $lang54; ?>
                                </span>
                            `}
                        </div>
                        ${hasLang ? `
                            <div class="mt-2">
                                <button class="btn btn-sm btn-outline-success" onclick="event.stopPropagation(); showCreateModalForPlugin('${plugin.name}')">
                                    <i class="fas fa-plus"></i> <?php echo $lang55; ?>
                                </button>
                                <button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation(); showUploadModalForPlugin('${plugin.name}')">
                                    <i class="fas fa-upload"></i> <?php echo $lang56; ?>
                                </button>
                            </div>
                        ` : `
                            <div class="mt-2">
                                <button class="btn btn-sm btn-outline-secondary" onclick="event.stopPropagation(); createLangFolder('${plugin.name}')">
                                    <i class="fas fa-folder-plus"></i> <?php echo $lang57; ?>
                                </button>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;
    });
    
    $('#pluginList').html(html);
}

function createLangFolder(plugin) {
    if (!confirm(`<?php echo $lang58; ?> "${plugin}"?`)) return;
    
    showAlert('<?php echo $lang59; ?>', 'info');
    
    fetch('lang_editor_api.php?action=create_language', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            code: 'En',
            name: 'English',
            author: 'System',
            version: '1.0.0',
            plugin: plugin
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('<?php echo $lang60; ?>', 'success');
            loadPlugins();
        } else {
            showAlert('Error: ' + data.error, 'danger');
        }
    })
    .catch(error => {
        showAlert('<?php echo $lang61; ?>' + error.message, 'danger');
    });
}

function showCreateModalForPlugin(plugin) {
    $('#createPlugin').val(plugin);
    $('#createPluginName').text(plugin);
    $('#createPluginInfo').show();
    $('#createLangCode').val('');
    $('#createLangName').val('');
    $('#createLangAuthor').val('Mini-B');
    $('#createLangVersion').val('1.0.0');
    $('#createLangIcon').val('');
    $('#createModal').modal('show');
}

function showUploadModalForPlugin(plugin) {
    $('#uploadPlugin').val(plugin);
    $('#uploadPluginName').text(plugin);
    $('#uploadPluginInfo').show();
    $('#uploadFile').val('');
    $('#uploadPreview').hide();
    $('#uploadModal').modal('show');
}

function showCreateModal() {
    $('#createPlugin').val('');
    $('#createPluginInfo').hide();
    $('#createLangCode').val('');
    $('#createLangName').val('');
    $('#createLangAuthor').val('Mini-B');
    $('#createLangVersion').val('1.0.0');
    $('#createLangIcon').val('');
    $('#createModal').modal('show');
}

function showUploadModal() {
    $('#uploadPlugin').val('');
    $('#uploadPluginInfo').hide();
    $('#uploadFile').val('');
    $('#uploadPreview').hide();
    $('#uploadModal').modal('show');
}

function showEditSettingsModal(code, name, icon, author, version, plugin) {
    $('#editLangCode').val(code);
    $('#editPlugin').val(plugin || '');
    $('#editLangName').val(name);
    $('#editLangAuthor').val(author || '');
    $('#editLangVersion').val(version || '');
    $('#editLangIcon').val(icon || '');
    $('#editLangIconFile').val('');
    
    if (plugin) {
        $('#editPluginName').text(plugin);
        $('#editPluginInfo').show();
    } else {
        $('#editPluginInfo').hide();
    }
    
    if (icon && icon.trim() !== '') {
        $('#currentIconPreview').html(`
            <img src="../../${icon}" class="preview-icon" style="max-width: 80px; max-height: 80px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'80\' height=\'80\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23999\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpath d=\'M4 4h16v16H4z\'/%3E%3Ccircle cx=\'12\' cy=\'12\' r=\'3\'/%3E%3C/svg%3E'">
            <p class="mb-0 small"><?php echo $lang62; ?></p>
        `);
    } else {
        $('#currentIconPreview').html(`
            <i class="fas fa-image fa-2x text-muted"></i>
            <p class="mb-0 small"><?php echo $lang63; ?></p>
        `);
    }
    
    $('#editSettingsModal').modal('show');
}

function restoreIconPreview() {
    const icon = $('#editLangIcon').val();
    if (icon && icon.trim() !== '') {
        $('#currentIconPreview').html(`
            <img src="../../${icon}" class="preview-icon" style="max-width: 80px; max-height: 80px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'80\' height=\'80\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23999\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpath d=\'M4 4h16v16H4z\'/%3E%3Ccircle cx=\'12\' cy=\'12\' r=\'3\'/%3E%3C/svg%3E'">
            <p class="mb-0 small"><?php echo $lang64; ?></p>
        `);
    } else {
        $('#currentIconPreview').html(`
            <i class="fas fa-image fa-2x text-muted"></i>
            <p class="mb-0 small"><?php echo $lang65; ?></p>
        `);
    }
}

async function saveLanguageSettings() {
    const code = $('#editLangCode').val();
    const plugin = $('#editPlugin').val() || null;
    const name = $('#editLangName').val().trim();
    const author = $('#editLangAuthor').val().trim();
    const version = $('#editLangVersion').val().trim();
    const iconPath = $('#editLangIcon').val().trim();
    const iconFile = $('#editLangIconFile')[0].files[0];
    
    if (!name) {
        showAlert('<?php echo $lang66; ?>', 'warning');
        return;
    }
    
    const action = plugin ? 'update_plugin_settings' : 'update_settings';
    
    if (iconFile) {
        const formData = new FormData();
        formData.append('file', iconFile);
        formData.append('code', code);
        if (plugin) formData.append('plugin', plugin);
        
        try {
            const uploadResponse = await fetch(`lang_editor_api.php?action=${plugin ? 'upload_plugin_icon' : 'upload_icon'}`, {
                method: 'POST',
                body: formData
            });
            const uploadResult = await uploadResponse.json();
            if (uploadResult.success && uploadResult.icon_path) {
                await updateLanguageSettings(action, code, name, author, version, uploadResult.icon_path, plugin);
            } else {
                showAlert('<?php echo $lang67; ?> ' + (uploadResult.error || 'Unknown error'), 'danger');
            }
        } catch (error) {
            showAlert('<?php echo $lang68; ?> ' + error.message, 'danger');
        }
    } else {
        await updateLanguageSettings(action, code, name, author, version, iconPath, plugin);
    }
}

async function updateLanguageSettings(action, code, name, author, version, icon, plugin) {
    try {
        const params = new URLSearchParams({
            code: code,
            name: name,
            author: author,
            version: version,
            icon: icon
        });
        if (plugin) params.append('plugin', plugin);
        
        const response = await fetch(`lang_editor_api.php?action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: params
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('<?php echo $lang69; ?>', 'success');
            $('#editSettingsModal').modal('hide');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showAlert('<?php echo $lang70; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang71; ?> ' + error.message, 'danger');
    }
}

async function downloadLanguage(code, plugin) {
    const url = `lang_editor_api.php?action=${plugin ? 'download_plugin_language' : 'download_language'}&code=${encodeURIComponent(code)}${plugin ? '&plugin=' + encodeURIComponent(plugin) : ''}`;
    
    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('<?php echo $lang72; ?>');
        }
        
        const blob = await response.blob();
        const url2 = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url2;
        a.download = code + '.php';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url2);
        
        showAlert(`<?php echo $lang73; ?> ${code}.php <?php echo $lang74; ?>`, 'success');
    } catch (error) {
        showAlert('<?php echo $lang75; ?> ' + error.message, 'danger');
    }
}

async function createLanguage() {
    const code = $('#createLangCode').val().trim();
	const formattedCode = code.charAt(0).toUpperCase() + code.slice(1).toLowerCase();
    const name = $('#createLangName').val().trim();
    const author = $('#createLangAuthor').val().trim();
    const version = $('#createLangVersion').val().trim();
    const icon = $('#createLangIcon').val().trim();
    const plugin = $('#createPlugin').val() || null;
    
    if (!code || !name) {
        showAlert('<?php echo $lang76; ?>', 'warning');
        return;
    }
    
    if (!/^[A-Za-z]{2}$/.test(code)) {
        showAlert('<?php echo $lang77; ?>', 'warning');
        return;
    }
    
    const action = plugin ? 'create_plugin_language' : 'create_language';
    
    showAlert('<?php echo $lang78; ?>', 'info');
    
    try {
        const params = new URLSearchParams({
            code: code,
            name: name,
            author: author,
            version: version,
            icon: icon
        });
        if (plugin) params.append('plugin', plugin);
        
        const response = await fetch(`lang_editor_api.php?action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: params
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert(`<?php echo $lang79; ?> "${name}" <?php echo $lang80; ?>`, 'success');
            $('#createModal').modal('hide');
            if (plugin) {
                loadPlugins();
                setTimeout(() => {
                    window.location.href = `plugin_edit.php?plugin=${encodeURIComponent(plugin)}`;
                }, 1000);
            } else {
                setTimeout(() => {
                    window.location.href = `edit.php?code=${code}`;
                }, 1000);
            }
        } else {
            showAlert('<?php echo $lang81; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang82; ?> ' + error.message, 'danger');
    }
}

async function uploadLanguage() {
    const fileInput = document.getElementById('uploadFile');
    const file = fileInput.files[0];
    const plugin = $('#uploadPlugin').val() || null;
    
    if (!file) {
        showAlert('<?php echo $lang83; ?>', 'warning');
        return;
    }
    
    if (!file.name.match(/^[A-Za-z]{2}\.php$/)) {
        showAlert('<?php echo $lang84; ?>', 'warning');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    if (plugin) formData.append('plugin', plugin);
    
    const action = plugin ? 'upload_plugin_language' : 'upload_language';
    
    showAlert('<?php echo $lang85; ?>', 'info');
    
    try {
        const response = await fetch(`lang_editor_api.php?action=${action}`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('<?php echo $lang86; ?>!', 'success');
            $('#uploadModal').modal('hide');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showAlert('<?php echo $lang87; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang88; ?> ' + error.message, 'danger');
    }
}

async function deleteLanguage(code, name, plugin) {
    if (!confirm(`<?php echo $lang89; ?> "${name}" (${code}.php)?\n\n<?php echo $lang90; ?>`)) {
        return;
    }
    
    const action = plugin ? 'delete_plugin_language' : 'delete_language';
    
    showAlert('<?php echo $lang91; ?>', 'info');
    
    try {
        const params = new URLSearchParams({ code: code });
        if (plugin) params.append('plugin', plugin);
        
        const response = await fetch(`lang_editor_api.php?action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: params
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert(`<?php echo $lang92; ?> "${name}" <?php echo $lang93; ?>`, 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showAlert('<?php echo $lang94; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang95; ?> ' + error.message, 'danger');
    }
}

function showAlert(message, type) {
    const icon = type === 'success' ? 'check-circle' : (type === 'danger' ? 'exclamation-triangle' : (type === 'warning' ? 'exclamation-triangle' : 'info-circle'));
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" style="position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px;">
            <i class="fas fa-${icon}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    $('#alertContainer').append(alertHtml);
    setTimeout(() => $('.alert').fadeOut(500, function() { $(this).remove(); }), 3000);
}
</script>
</body>
</html>