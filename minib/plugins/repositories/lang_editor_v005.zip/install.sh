#!/bin/bash

# Пути
MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/lang_editor"
LANG_DIR="/var/www/html/admin/plugins/lang_editor/lang"
MINIB_DIR="/var/www/minib/plugins/installed/lang_editor"

# Создаем папки
mkdir -p $ADMIN_DIR
mkdir -p $LANG_DIR
mkdir -p $MINIB_DIR

# Назначаем владельца и права
chown -R www-data:www-data $ADMIN_DIR
chown -R www-data:www-data $MINIB_DIR
chmod -R 755 $ADMIN_DIR
chmod -R 755 $MINIB_DIR
chmod +x uninstall.sh

# Копируем файлы в admin
cp -pr lang/  $ADMIN_DIR/
cp -p lang_editor.php $ADMIN_DIR/
cp -p lang_editor_api.php $ADMIN_DIR/
cp -p edit.php $ADMIN_DIR/
cp -p plugin_edit.php $ADMIN_DIR/
cp -p menu/lang_editor.php $MENU_DIR/

# Копируем файлы в minib
cp -p install.php $MINIB_DIR/
cp -p info.json $MINIB_DIR/
cp -p uninstall.sh $MINIB_DIR/

# Удаляем папку extract если есть
rm -rf /var/www/minib/plugins/extract/lang_editor*
