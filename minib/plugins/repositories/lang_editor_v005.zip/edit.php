<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Lang Editor" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();
require_once 'lang/loader.php';

$current_host_id = $_SESSION['current_host_id'] ?? 1;
$menu = require_once dirname(dirname(dirname(__FILE__))) . '/menu.php';

$lang_code = $_GET['code'] ?? '';
if (empty($lang_code)) {
    header('Location: lang_editor.php');
    exit;
}

$lang_file = dirname(dirname(dirname(__FILE__))) . '/lang/' . $lang_code . '.php';

if (!file_exists($lang_file)) {
    header('Location: lang_editor.php');
    exit;
}

// Parse language file
$content = file_get_contents($lang_file);

// Get metadata
$metadata = [];
if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) $metadata['name'] = $m[1];
if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) $metadata['icon'] = $m[1];
if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) $metadata['author'] = $m[1];
if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) $metadata['version'] = $m[1];

// Get all variables
$variables = [];
preg_match_all('/\$lang(\d+)\s*=\s*"([^"\\\\]*(?:\\\\.[^"\\\\]*)*)"/', $content, $matches, PREG_SET_ORDER);
foreach ($matches as $match) {
    $variables[] = [
        'key' => 'lang' . $match[1],
        'number' => (int)$match[1],
        'value' => stripslashes($match[2])
    ];
}

// Sort by number
usort($variables, function($a, $b) {
    return $a['number'] - $b['number'];
});

// Get next available number
$next_number = 1;
if (!empty($variables)) {
    $max_number = max(array_column($variables, 'number'));
    $next_number = $max_number + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit <?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?> - Language Editor</title>
    <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../css/loader.css">
    <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            height: 100%;
            overflow: hidden;
        }
        
        .app-container {
            display: flex;
            height: calc(100vh - 60px);
            overflow: hidden;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            padding: 24px 32px;
            overflow: hidden;
            margin-left: 260px;
        }
        
        .search-bar {
            position: sticky;
            top: 0;
            z-index: 99;
            padding: 10px 0 15px 0;
            background: #f0f2f5;
            flex-shrink: 0;
        }
        
        .table-wrapper {
            flex: 1;
            overflow-y: auto;
            margin-bottom: 10px;
            background: white;
            border-radius: 12px;
        }
        
        .table-wrapper table {
            margin-bottom: 0;
        }
        
        .variables-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .variables-table thead {
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .variables-table th {
            background: #f8f9fa;
            padding: 12px 16px;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .variables-table td {
            padding: 12px 16px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }
        
        .variable-key {
            font-family: monospace;
            font-weight: 600;
            color: #007aff;
            background: #f0f0f0;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            transition: background 0.2s;
            user-select: all;
            display: inline-block;
        }
        .variable-key:hover {
            background: #d4e4ff;
        }
        .variable-key:active {
            background: #b3d0ff;
        }
        
        .variable-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: monospace;
            font-size: 13px;
            transition: all 0.2s;
        }
        .variable-input:focus {
            outline: none;
            border-color: #007aff;
            box-shadow: 0 0 0 2px rgba(0,122,255,0.1);
        }
        
        .copy-btn {
            padding: 4px 8px;
            font-size: 12px;
        }
        
        .save-status {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
        }
        
        /* Bottom fixed panel */
        .bottom-panel {
            flex-shrink: 0;
            background: white;
            border-radius: 12px;
            padding: 12px 16px;
			margin-bottom: 40px;
            margin-top: 10px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .bottom-panel .input-group {
            flex: 1;
            min-width: 200px;
        }
        
        .bottom-panel .copy-options {
            display: flex;
            gap: 15px;
            align-items: center;
            font-size: 13px;
            margin: 0 10px;
        }
        
        .bottom-panel .copy-options label {
            margin-bottom: 0;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .bottom-panel .copy-options input[type="radio"] {
            margin-right: 2px;
        }
        
        .bottom-panel .btn {
            white-space: nowrap;
        }
        
        .bottom-nav {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-shrink: 0;
        }
        
        /* Scrollbar styling */
        .table-wrapper::-webkit-scrollbar {
            width: 8px;
        }
        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        .table-wrapper::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .variables-table td {
                padding: 8px;
            }
            .bottom-panel {
                flex-direction: column;
                align-items: stretch;
            }
            .bottom-panel .copy-options {
                margin: 5px 0;
                justify-content: center;
            }
            .bottom-nav {
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div id="applePreloader" class="apple-preloader">
    <div class="apple-spinner"></div>
    <div class="apple-spinner-text"><?php echo $lang2; ?></div>
</div>

<div class="top-bar">
    <div class="top-bar-left">
        <h1><i class="fas fa-bucket"></i> Mini-B</h1>
    </div>
    <div class="top-bar-right">
        <h5 class="d-inline-block mb-0 ms-2">
            <i class="fas fa-edit text-primary"></i>
            Editing: <?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>
            <small class="text-muted">(<?php echo $lang_code; ?>.php)</small>
        </h5>
        
        <button class="btn btn-secondary btn-sm me-2" onclick="window.location.href='lang_editor.php'">
            <i class="fas fa-arrow-left"></i> <?php echo $lang128; ?>
        </button>
        
        <span id="saveStatus" class="save-status text-muted me-2 ms-2">
            <i class="fas fa-check-circle"></i> <?php echo $lang129; ?>
        </span>
        
        <button class="btn btn-success btn-sm me-2" onclick="showAddVariableModal()">
            <i class="fas fa-plus"></i> <?php echo $lang130; ?>
        </button>
        
        <button class="btn btn-primary btn-sm me-2" onclick="saveAll()">
            <i class="fas fa-save"></i> <?php echo $lang131; ?>
        </button>
        
        <button class="btn btn-secondary btn-sm" onclick="showSaveAsModal()">
            <i class="fas fa-copy"></i> <?php echo $lang132; ?>
        </button>
    </div>
</div>

<div class="app-container">
    <?php echo $menu; ?>
    
    <main class="main-content">
        <div id="alertContainer"></div>
        
        <!-- Search Bar -->
        <div class="search-bar">
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
                <input type="text" class="form-control" id="searchInput" placeholder="<?php echo $lang133; ?>">
                <button class="btn btn-outline-secondary" onclick="clearSearch()">
                    <i class="fas fa-times"></i> <?php echo $lang134; ?>
                </button>
            </div>
        </div>
        
        <!-- Variables Table -->
        <div class="variables-table">
            <div class="table-wrapper" id="tableWrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th style="width: 150px"><?php echo $lang135; ?></th>
                            <th>Value</th>
                            <th style="width: 120px"><?php echo $lang136; ?></th>
                        </tr>
                    </thead>
                    <tbody id="variablesBody">
                        <?php foreach ($variables as $var): ?>
                        <tr data-key="<?php echo $var['key']; ?>" data-number="<?php echo $var['number']; ?>">
                            <td>
                                <code class="variable-key" onclick="copyVariableName('<?php echo $var['key']; ?>')" title="Click to copy variable name">$<?php echo $var['key']; ?></code>
                            </td>
                            <td>
                                <input type="text" class="variable-input" data-key="<?php echo $var['key']; ?>" value="<?php echo htmlspecialchars($var['value']); ?>">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('<?php echo $var['key']; ?>')" title="<?php echo $lang137; ?>">
                                    <i class="fas fa-copy"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '<?php echo $var['key']; ?>')" title="<?php echo $lang138; ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (empty($variables)): ?>
            <div class="text-center text-muted py-5">
                <i class="fas fa-code fa-4x mb-3"></i>
                <p><?php echo $lang139; ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Bottom Fixed Panel -->
        <div class="bottom-panel">
            <div class="input-group">
                <input type="text" class="form-control" id="quickAddInput" placeholder="<?php echo $lang140; ?>" style="font-family: monospace;">
                <button class="btn btn-success" onclick="quickAddVariable()">
                    <i class="fas fa-plus"></i> <?php echo $lang141; ?>
                </button>
            </div>
            
            <div class="copy-options">
                <label>
                    <input type="radio" name="copyMode" value="php" checked>
                    <?php echo $lang142; ?>
                </label>
                <label>
                    <input type="radio" name="copyMode" value="html">
                    <?php echo $lang143; ?>
                </label>
                <label>
                    <input type="radio" name="copyMode" value="none">
                    <?php echo $lang144; ?>
                </label>
            </div>
            
            <div class="bottom-nav">
                <button class="btn btn-sm btn-outline-secondary" onclick="scrollToTop()" title="<?php echo $lang145; ?>">
                    <i class="fas fa-arrow-up"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" onclick="scrollToBottom()" title="<?php echo $lang146; ?>">
                    <i class="fas fa-arrow-down"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" onclick="window.location.href='lang_editor.php'" title="<?php echo $lang147; ?>">
                    <i class="fas fa-list"></i>
                </button>
            </div>
        </div>
    </main>
</div>

<!-- Add Variable Modal -->
<div class="modal fade" id="addVariableModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="fas fa-plus"></i> <?php echo $lang148; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang149; ?></label>
                    <input type="text" class="form-control" id="newVarKey" readonly value="lang<?php echo $next_number; ?>">
                    <small class="text-muted"><?php echo $lang150; ?> <?php echo $next_number; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang151; ?></label>
                    <textarea class="form-control" id="newVarValue" rows="3" placeholder="<?php echo $lang152; ?>"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang153; ?></button>
                <button type="button" class="btn btn-success" onclick="addNewVariable()"><?php echo $lang154; ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Save As Modal -->
<div class="modal fade" id="saveAsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-copy"></i> <?php echo $lang155; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang156; ?> *</label>
                    <input type="text" class="form-control" id="newLangCode" placeholder="De, Fr, Es" maxlength="2" style="text-transform: uppercase;">
                    <small class="text-muted"><?php echo $lang157; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang158; ?> *</label>
                    <input type="text" class="form-control" id="newLangName" value="<?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang159; ?></label>
                    <input type="text" class="form-control" id="newLangAuthor" value="<?php echo htmlspecialchars($metadata['author'] ?? 'Mini-B'); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang160; ?></label>
                    <input type="text" class="form-control" id="newLangVersion" value="<?php echo htmlspecialchars($metadata['version'] ?? '1.0.0'); ?>">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang161; ?></button>
                <button type="button" class="btn btn-primary" onclick="saveAsLanguage()"><?php echo $lang162; ?></button>
            </div>
        </div>
    </div>
</div>

<script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
<script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="../../js/loader.js"></script>

<script>
let currentLangCode = '<?php echo $lang_code; ?>';

$(document).ready(function() {
    // Search functionality
    $('#searchInput').on('keyup', function() {
        const search = $(this).val().toLowerCase();
        
        $('#variablesBody tr').each(function() {
            const key = $(this).data('key').toLowerCase();
            const value = $(this).find('.variable-input').val().toLowerCase();
            
            if (key.includes(search) || value.includes(search)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Mark unsaved on input change
    $(document).on('input', '.variable-input', function() {
        $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> Unsaved').removeClass('text-muted text-success').addClass('text-warning');
    });
    
    // Quick add on Enter key
    $('#quickAddInput').on('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            quickAddVariable();
        }
    });
    
    setTimeout(() => $('#applePreloader').fadeOut(500), 500);
    
    // Focus the quick add input
    setTimeout(() => $('#quickAddInput').focus(), 600);
});

function clearSearch() {
    $('#searchInput').val('');
    $('#variablesBody tr').show();
}

// Scroll functions
function scrollToTop() {
    document.getElementById('tableWrapper').scrollTop = 0;
}

function scrollToBottom() {
    const wrapper = document.getElementById('tableWrapper');
    wrapper.scrollTop = wrapper.scrollHeight;
}

function scrollToLastRow() {
    const wrapper = document.getElementById('tableWrapper');
    const rows = $('#variablesBody tr');
    if (rows.length > 0) {
        const lastRow = rows[rows.length - 1];
        const rowTop = lastRow.offsetTop;
        const rowHeight = lastRow.offsetHeight;
        wrapper.scrollTop = rowTop - wrapper.offsetHeight + rowHeight + 20;
    }
}

// Copy variable name on click
function copyVariableName(key) {
    const fullName = '$' + key;
    
    navigator.clipboard.writeText(fullName).then(() => {
        showAlert('Copied: <code>' + fullName + '</code>', 'success');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = fullName;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showAlert('Copied: <code>' + fullName + '</code>', 'success');
    });
}

// Quick add variable from input
function quickAddVariable() {
    const input = $('#quickAddInput');
    const value = input.val();
    
    if (!value) {
        showAlert('<?php echo $lang163; ?>', 'warning');
        input.focus();
        return;
    }
    
    // Get next available number
    let maxNumber = 0;
    $('#variablesBody tr').each(function() {
        const num = parseInt($(this).data('number'));
        if (num > maxNumber) maxNumber = num;
    });
    const nextNumber = maxNumber + 1;
    const key = 'lang' + nextNumber;
    
    // Check if variable already exists
    let exists = false;
    $('#variablesBody tr').each(function() {
        if ($(this).data('key') === key) {
            exists = true;
            return false;
        }
    });
    
    if (exists) {
        showAlert('<?php echo $lang164; ?>', 'danger');
        return;
    }
    
    // Add new row to table
    const newRow = `
        <tr data-key="${escapeHtml(key)}" data-number="${nextNumber}">
            <td>
                <code class="variable-key" onclick="copyVariableName('${escapeHtml(key)}')" title="<?php echo $lang165; ?>">$${escapeHtml(key)}</code>
            </td>
            <td>
                <input type="text" class="variable-input" data-key="${escapeHtml(key)}" value="${escapeHtml(value)}">
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('${escapeHtml(key)}')" title="<?php echo $lang166; ?>">
                    <i class="fas fa-copy"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '${escapeHtml(key)}')" title="<?php echo $lang167; ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    
    $('#variablesBody').append(newRow);
    
    // Handle copy based on selected mode
    const copyMode = $('input[name="copyMode"]:checked').val();
    
    if (copyMode === 'php') {
        copyVariableName(key);
    } else if (copyMode === 'html') {
        copyVariable(key);
    }
    // 'none' mode: just add, no copy
    
    // Clear input and refocus
    input.val('');
    input.focus();
    
    // Scroll to the new row
    setTimeout(() => scrollToLastRow(), 100);
    
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang168; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang169; ?> ' + key + ' <?php echo $lang170; ?>', 'success');
}

// Copy variable (existing function)
function copyVariable(key) {
    const code = '<\?php echo $' + key + '; ?>';
    
    navigator.clipboard.writeText(code).then(() => {
        const displayCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        showAlert('<?php echo $lang171; ?> ' + displayCode, 'success');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = code;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        const displayCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        showAlert('<?php echo $lang172; ?> ' + displayCode, 'success');
    });
}

// Delete variable row
function deleteVariableRow(btn, key) {
    if (!confirm('<?php echo $lang173; ?> ' + key + '?')) return;
    
    // Remove the row from DOM
    $(btn).closest('tr').remove();
    
    // Mark as unsaved
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang174; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang175; ?> ' + key + ' <?php echo $lang176; ?>', 'info');
}

function showAddVariableModal() {
    let maxNumber = 0;
    $('#variablesBody tr').each(function() {
        const num = parseInt($(this).data('number'));
        if (num > maxNumber) maxNumber = num;
    });
    const nextNumber = maxNumber + 1;
    
    $('#newVarKey').val('lang' + nextNumber);
    $('#newVarValue').val('');
    $('#addVariableModal').modal('show');
}

function addNewVariable() {
    const key = $('#newVarKey').val();
    const value = $('#newVarValue').val();
    const number = parseInt(key.replace('lang', ''));
    
    let exists = false;
    $('#variablesBody tr').each(function() {
        if ($(this).data('key') === key) {
            exists = true;
            return false;
        }
    });
    
    if (exists) {
        showAlert('<?php echo $lang177; ?>', 'danger');
        return;
    }
    
    const newRow = `
        <tr data-key="${escapeHtml(key)}" data-number="${number}">
            <td>
                <code class="variable-key" onclick="copyVariableName('${escapeHtml(key)}')" title="<?php echo $lang178; ?>">$${escapeHtml(key)}</code>
            </td>
            <td>
                <input type="text" class="variable-input" data-key="${escapeHtml(key)}" value="${escapeHtml(value)}">
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('${escapeHtml(key)}')" title="<?php echo $lang179; ?>">
                    <i class="fas fa-copy"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '${escapeHtml(key)}')" title="<?php echo $lang180; ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    
    $('#variablesBody').append(newRow);
    
    // Scroll to the new row
    setTimeout(() => scrollToLastRow(), 100);
    
    $('#addVariableModal').modal('hide');
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang181; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang182; ?> ' + key + ' <?php echo $lang183; ?>', 'success');
}

async function saveAll() {
    const variables = [];
    
    $('#variablesBody tr').each(function() {
        const key = $(this).data('key');
        const value = $(this).find('.variable-input').val();
        const number = parseInt(key.replace('lang', ''));
        variables.push({ key: key, number: number, value: value });
    });
    
    $('#saveStatus').html('<i class="fas fa-spinner fa-spin"></i> <?php echo $lang184; ?>').removeClass('text-warning text-muted').addClass('text-info');
    
    try {
        const response = await fetch('lang_editor_api.php?action=save_language', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                code: currentLangCode,
                variables: JSON.stringify(variables)
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            $('#saveStatus').html('<i class="fas fa-check-circle"></i> <?php echo $lang185; ?>').removeClass('text-info').addClass('text-success');
            
            setTimeout(() => {
                $('#saveStatus').html('<i class="fas fa-check-circle"></i> <?php echo $lang186; ?>').removeClass('text-success').addClass('text-muted');
            }, 2000);
            
            showAlert('<?php echo $lang187; ?>', 'success');
            
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang188; ?>').removeClass('text-info').addClass('text-danger');
            showAlert('<?php echo $lang189; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        console.error('Save error:', error);
        $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang190; ?>').removeClass('text-info').addClass('text-danger');
        showAlert('<?php echo $lang191; ?>', 'danger');
    }
}

function showSaveAsModal() {
    $('#newLangCode').val('');
    $('#newLangName').val('<?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>');
    $('#newLangAuthor').val('<?php echo htmlspecialchars($metadata['author'] ?? 'Mini-B'); ?>');
    $('#newLangVersion').val('<?php echo htmlspecialchars($metadata['version'] ?? '1.0.0'); ?>');
    $('#saveAsModal').modal('show');
}

async function saveAsLanguage() {
    const newCode = $('#newLangCode').val().trim().toUpperCase();
    const newName = $('#newLangName').val().trim();
    const newAuthor = $('#newLangAuthor').val().trim();
    const newVersion = $('#newLangVersion').val().trim();
    
    if (!newCode || !newName) {
        showAlert('<?php echo $lang192; ?>', 'warning');
        return;
    }
    
    if (!/^[A-Z]{2}$/.test(newCode)) {
        showAlert('<?php echo $lang193; ?>', 'warning');
        return;
    }
    
    const variables = [];
    $('#variablesBody tr').each(function() {
        const key = $(this).data('key');
        const value = $(this).find('.variable-input').val();
        const number = parseInt(key.replace('lang', ''));
        variables.push({ number: number, value: value });
    });
    
    try {
        const response = await fetch('lang_editor_api.php?action=save_as', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                source_code: currentLangCode,
                new_code: newCode,
                new_name: newName,
                new_author: newAuthor,
                new_version: newVersion,
                variables: JSON.stringify(variables)
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('<?php echo $lang194; ?> "' + newName + '"', 'success');
            $('#saveAsModal').modal('hide');
            window.location.href = 'edit.php?code=' + newCode;
        } else {
            showAlert('<?php echo $lang195; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang196; ?> ' + error.message, 'danger');
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function showAlert(message, type) {
    const icon = type === 'success' ? 'check-circle' : (type === 'danger' ? 'exclamation-triangle' : (type === 'warning' ? 'exclamation-triangle' : 'info-circle'));
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" style="position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; max-width: 500px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <i class="fas fa-${icon}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    $('#alertContainer').append(alertHtml);
    setTimeout(() => $('.alert').fadeOut(500, function() { $(this).remove(); }), 3000);
}
</script>
</body>
</html>