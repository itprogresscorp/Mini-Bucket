<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Lang Editor" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();
require_once 'lang/loader.php';

$current_host_id = $_SESSION['current_host_id'] ?? 1;
$menu = require_once dirname(dirname(dirname(__FILE__))) . '/menu.php';

$plugin = $_GET['plugin'] ?? '';
$lang_code = $_GET['code'] ?? '';

if (empty($plugin)) {
    header('Location: lang_editor.php#plugins');
    exit;
}

$plugin_dir = dirname(dirname(dirname(__FILE__))) . '/plugins/' . $plugin;
$lang_dir = $plugin_dir . '/lang/';

if (!is_dir($plugin_dir) || !is_dir($lang_dir)) {
    header('Location: lang_editor.php#plugins');
    exit;
}

if (empty($lang_code)) {
    $languages = [];
    $files = scandir($lang_dir);
    foreach ($files as $file) {
        if (preg_match('/^([A-Za-z]+)\.php$/', $file, $matches)) {
            $code = $matches[1];
            $content = file_get_contents($lang_dir . $file);
            
            $name = $code;
            $icon = '';
            $author = '';
            $version = '';
            $date_update = '';
            
            if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) {
                $name = $m[1];
            }
            if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) {
                $icon = $m[1];
            }
            if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) {
                $author = $m[1];
            }
            if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) {
                $version = $m[1];
            }
            if (preg_match('/\$LANG_DATE_UPDATE\s*=\s*"([^"]+)"/', $content, $m)) {
                $date_update = $m[1];
            }
            
            preg_match_all('/\$lang\d+\s*=/', $content, $var_count);
            
            $languages[] = [
                'code' => $code,
                'name' => $name,
                'icon' => $icon,
                'author' => $author,
                'version' => $version,
                'date_update' => $date_update,
                'file' => $file,
                'size' => filesize($lang_dir . $file),
                'modified' => date('Y-m-d H:i:s', filemtime($lang_dir . $file)),
                'variables' => count($var_count[0])
            ];
        }
    }
    
    usort($languages, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Plugin Languages - <?php echo htmlspecialchars($plugin); ?></title>
        <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
        <link rel="stylesheet" href="../../style.css">
        <link rel="stylesheet" href="../../css/loader.css">
        <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
        <style>
            .main-content {
                margin-left: 260px;
                padding: 24px 32px;
                flex: 1;
            }
            .lang-card {
                transition: all 0.2s;
                cursor: pointer;
                border-left: 3px solid #007aff;
            }
            .lang-card:hover {
                transform: translateX(3px);
                background: #f8f9fa;
            }
            .stats-badge {
                font-size: 11px;
                padding: 4px 8px;
                border-radius: 20px;
            }
            .search-box {
                position: relative;
                margin-bottom: 20px;
            }
            .search-box i {
                position: absolute;
                left: 12px;
                top: 12px;
                color: #6c757d;
            }
            .search-box input {
                padding-left: 35px;
            }
            .card-actions {
                position: absolute;
                top: 10px;
                right: 10px;
                z-index: 10;
                display: flex;
                gap: 5px;
            }
            .card-actions .btn {
                padding: 4px 8px;
                font-size: 12px;
                margin-top: 0;
            }
            .lang-card {
                position: relative;
            }
            .lang-icon {
                width: 16px;
                height: 16px;
                object-fit: cover;
                border-radius: 8px;
                margin-right: 12px;
            }
            .lang-icon-placeholder {
                width: 48px;
                height: 48px;
                border-radius: 8px;
                background: #f0f0f0;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 12px;
            }
            .preview-icon {
                max-width: 80px;
                max-height: 80px;
                border-radius: 12px;
                border: 1px solid #ddd;
                padding: 5px;
            }
            .icon-preview-area {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                text-align: center;
            }
            .plugin-header {
                background: linear-gradient(135deg, #e3f2fd, #bbdefb);
                border-radius: 12px;
                padding: 20px 24px;
                margin-bottom: 24px;
            }
            .plugin-icon {
                width: 56px;
                height: 56px;
                background: #007aff;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            @media (max-width: 768px) {
                .main-content {
                    margin-left: 0;
                    padding: 20px;
                }
            }
        </style>
    </head>
    <body>
    <div id="applePreloader" class="apple-preloader">
        <div class="apple-spinner"></div>
        <div class="apple-spinner-text"><?php echo $lang2; ?></div>
    </div>

    <div class="top-bar">
        <div class="top-bar-left">
            <h1><i class="fas fa-bucket"></i> Mini-B</h1>
        </div>
        <div class="top-bar-right">
            <text><i class="fas fa-puzzle-piece text-primary"></i> <?php echo $lang197; ?> <?php echo htmlspecialchars($plugin); ?></text>
            <button class="btn btn-secondary btn-sm me-2" onclick="window.location.href='lang_editor.php#plugins'">
                <i class="fas fa-arrow-left"></i> <?php echo $lang198; ?>
            </button>
            
            <button class="btn btn-success btn-sm me-2" onclick="showCreateModal()">
                <i class="fas fa-plus"></i> <?php echo $lang199; ?>
            </button>
            
            <button class="btn btn-primary btn-sm" onclick="showUploadModal()">
                <i class="fas fa-upload"></i> <?php echo $lang200; ?>
            </button>
        </div>
    </div>

    <div class="app-container">
        <?php echo $menu; ?>
        
        <main class="main-content">
            <div id="alertContainer"></div>
            
            <div class="plugin-header">
                <div class="d-flex align-items-center">
                    <div class="plugin-icon me-3">
                        <i class="fas fa-puzzle-piece fa-2x text-white"></i>
                    </div>
                    <div>
                        <h3 class="mb-0"><?php echo htmlspecialchars($plugin); ?></h3>
                        <small class="text-muted">/plugins/<?php echo htmlspecialchars($plugin); ?>/lang/</small>
                    </div>
                    <div class="ms-auto">
                        <span class="badge bg-primary stats-badge">
                            <i class="fas fa-code"></i> <?php echo count($languages); ?> <?php echo $lang201; ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="widget">
                <div class="widget-body">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" id="searchLang" placeholder="<?php echo $lang202; ?>">
                    </div>
                    
                    <div class="row" id="languageList">
                        <?php foreach ($languages as $lang): ?>
                        <div class="col-md-6 col-lg-4 mb-3 lang-item" data-name="<?php echo strtolower($lang['name']); ?>" data-code="<?php echo strtolower($lang['code']); ?>">
                            <div class="card lang-card h-100">
                                <div class="card-actions">
                                    <div class="btn-group">
                                    <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-cog"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li><a class="dropdown-item text-success" href="#" onclick="event.stopPropagation(); downloadLanguage('<?php echo $lang['code']; ?>')"><i class="fas fa-download me-2"></i> <?php echo $lang203; ?></a></li>
                                        <li><a class="dropdown-item text-info" href="#" onclick="event.stopPropagation(); showEditSettingsModal('<?php echo $lang['code']; ?>', '<?php echo addslashes($lang['name']); ?>', '<?php echo addslashes($lang['icon']); ?>', '<?php echo addslashes($lang['author']); ?>', '<?php echo addslashes($lang['version']); ?>')"><i class="fas fa-edit me-2"></i> <?php echo $lang204; ?></a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="#" onclick="event.stopPropagation(); deleteLanguage('<?php echo $lang['code']; ?>', '<?php echo addslashes($lang['name']); ?>')"><i class="fas fa-trash me-2"></i> <?php echo $lang205; ?></a></li>
                                    </ul>
                                </div>
                                </div>
                                <div class="card-body" onclick="window.location.href='plugin_edit.php?plugin=<?php echo urlencode($plugin); ?>&code=<?php echo $lang['code']; ?>'" style="cursor: pointer;">
                                    <div class="d-flex align-items-start">
                                        <?php if (!empty($lang['icon']) && file_exists(dirname(dirname(dirname(__FILE__))) . '/' . $lang['icon'])): ?>
                                            <img src="../../<?php echo $lang['icon']; ?>" class="lang-icon" alt="<?php echo htmlspecialchars($lang['name']); ?>" onerror="this.style.display='none'; this.nextSibling.style.display='flex';">
                                            <div class="lang-icon-placeholder" style="display: none;">
                                                <i class="fas fa-language fa-2x text-muted"></i>
                                            </div>
                                        <?php else: ?>
                                            <div class="lang-icon-placeholder">
                                                <i class="fas fa-language fa-2x text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div style="flex: 1;">
                                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($lang['name']); ?></h5>
                                            <small class="text-muted"><?php echo $lang['code']; ?>.php</small>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <small class="text-muted">
                                            <i class="far fa-calendar-alt"></i> <?php echo $lang['modified']; ?>
                                        </small>
                                        <br>
                                        <small class="text-muted">
                                            <i class="fas fa-database"></i> <?php echo round($lang['size'] / 1024, 2); ?> KB
                                        </small>
                                        <?php if (!empty($lang['version'])): ?>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-tag"></i> v<?php echo htmlspecialchars($lang['version']); ?>
                                            </small>
                                        <?php endif; ?>
                                        <div class="text-end">
                                            <span class="badge bg-secondary stats-badge">
                                                <i class="fas fa-code"></i> <?php echo $lang['variables']; ?> <?php echo $lang206; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (empty($languages)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-folder-open fa-4x mb-3"></i>
                        <p><?php echo $lang207; ?></p>
                        <button class="btn btn-success" onclick="showCreateModal()">
                            <i class="fas fa-plus"></i> <?php echo $lang208; ?>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Create Language Modal -->
    <div class="modal fade" id="createModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> <?php echo $lang209; ?> <?php echo htmlspecialchars($plugin); ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang210; ?> *</label>
                        <input type="text" class="form-control" id="createLangCode" placeholder="e.g., De, Fr, Es" maxlength="2" style="text-transform: uppercase;">
                        <small class="text-muted"><?php echo $lang211; ?></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang212; ?> *</label>
                        <input type="text" class="form-control" id="createLangName" placeholder="e.g., Deutsch, Français">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang213; ?></label>
                        <input type="text" class="form-control" id="createLangAuthor" value="Mini-B">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang214; ?></label>
                        <input type="text" class="form-control" id="createLangVersion" value="1.0.0">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang215; ?></label>
                        <input type="text" class="form-control" id="createLangIcon" placeholder="plugins/<?php echo $plugin; ?>/lang/icon/De.png">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang216; ?></button>
                    <button type="button" class="btn btn-success" onclick="createLanguage()"><?php echo $lang217; ?></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Settings Modal -->
    <div class="modal fade" id="editSettingsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-cog"></i> <?php echo $lang218; ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editLangCode">
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang219; ?> *</label>
                        <input type="text" class="form-control" id="editLangName" placeholder="Language Name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang220; ?></label>
                        <input type="text" class="form-control" id="editLangAuthor" placeholder="Author">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang221; ?></label>
                        <input type="text" class="form-control" id="editLangVersion" placeholder="Version">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang222; ?></label>
                        <input type="text" class="form-control" id="editLangIcon" placeholder="plugins/<?php echo $plugin; ?>/lang/icon/De.png">
                        <small class="text-muted"><?php echo $lang223; ?></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang224; ?></label>
                        <input type="file" class="form-control" id="editLangIconFile" accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp">
                        <small class="text-muted">PNG, JPG, GIF, SVG, WEBP (Max 2MB)</small>
                    </div>
                    <div class="icon-preview-area" id="iconPreviewArea">
                        <div id="currentIconPreview">
                            <i class="fas fa-image fa-2x text-muted"></i>
                            <p class="mb-0 small"><?php echo $lang225; ?></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang226; ?></button>
                    <button type="button" class="btn btn-info" onclick="saveLanguageSettings()"><?php echo $lang227; ?></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Upload Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-upload"></i> <?php echo $lang228; ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang229; ?></label>
                        <input type="file" class="form-control" id="uploadFile" accept=".php">
                        <small class="text-muted"><?php echo $lang230; ?></small>
                    </div>
                    <div id="uploadPreview" style="display: none;" class="mt-3">
                        <div class="alert alert-info">
                            <strong><i class="fas fa-info-circle"></i> <?php echo $lang231; ?></strong><br>
                            <?php echo $lang232; ?> <span id="previewName"></span><br>
                            <?php echo $lang233; ?> <span id="previewSize"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang234; ?></button>
                    <button type="button" class="btn btn-primary" onclick="uploadLanguage()"><?php echo $lang235; ?></button>
                </div>
            </div>
        </div>
    </div>

    <script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
    <script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../js/loader.js"></script>
    <script>
    const pluginName = '<?php echo addslashes($plugin); ?>';
    
    $(document).ready(function() {
        $('#searchLang').on('keyup', function() {
            const search = $(this).val().toLowerCase();
            $('.lang-item').each(function() {
                const name = $(this).data('name');
                const code = $(this).data('code');
                if (name.includes(search) || code.includes(search)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
        
        $('#uploadFile').on('change', function() {
            const file = this.files[0];
            if (file) {
                $('#previewName').text(file.name);
                $('#previewSize').text((file.size / 1024).toFixed(2) + ' KB');
                $('#uploadPreview').show();
            } else {
                $('#uploadPreview').hide();
            }
        });
        
        $('#editLangIconFile').on('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#currentIconPreview').html(`
                        <img src="${e.target.result}" class="preview-icon" style="max-width: 80px; max-height: 80px;">
                        <p class="mb-0 small"><?php echo $lang236; ?></p>
                    `);
                };
                reader.readAsDataURL(file);
            } else {
                restoreIconPreview();
            }
        });
        
        setTimeout(() => $('#applePreloader').fadeOut(500), 500);
    });

    function showCreateModal() {
        $('#createLangCode').val('');
        $('#createLangName').val('');
        $('#createLangAuthor').val('Mini-B');
        $('#createLangVersion').val('1.0.0');
        $('#createLangIcon').val('');
        $('#createModal').modal('show');
    }

    function showUploadModal() {
        $('#uploadFile').val('');
        $('#uploadPreview').hide();
        $('#uploadModal').modal('show');
    }

    function showEditSettingsModal(code, name, icon, author, version) {
        $('#editLangCode').val(code);
        $('#editLangName').val(name);
        $('#editLangAuthor').val(author || '');
        $('#editLangVersion').val(version || '');
        $('#editLangIcon').val(icon || '');
        $('#editLangIconFile').val('');
        
        if (icon && icon.trim() !== '') {
            $('#currentIconPreview').html(`
                <img src="../../${icon}" class="preview-icon" style="max-width: 80px; max-height: 80px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'80\' height=\'80\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23999\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpath d=\'M4 4h16v16H4z\'/%3E%3Ccircle cx=\'12\' cy=\'12\' r=\'3\'/%3E%3C/svg%3E'">
                <p class="mb-0 small"><?php echo $lang237; ?></p>
            `);
        } else {
            $('#currentIconPreview').html(`
                <i class="fas fa-image fa-2x text-muted"></i>
                <p class="mb-0 small"><?php echo $lang238; ?></p>
            `);
        }
        
        $('#editSettingsModal').modal('show');
    }

    function restoreIconPreview() {
        const icon = $('#editLangIcon').val();
        if (icon && icon.trim() !== '') {
            $('#currentIconPreview').html(`
                <img src="../../${icon}" class="preview-icon" style="max-width: 80px; max-height: 80px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'80\' height=\'80\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23999\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpath d=\'M4 4h16v16H4z\'/%3E%3Ccircle cx=\'12\' cy=\'12\' r=\'3\'/%3E%3C/svg%3E'">
                <p class="mb-0 small"><?php echo $lang239; ?></p>
            `);
        } else {
            $('#currentIconPreview').html(`
                <i class="fas fa-image fa-2x text-muted"></i>
                <p class="mb-0 small"><?php echo $lang240; ?></p>
            `);
        }
    }

    async function saveLanguageSettings() {
        const code = $('#editLangCode').val();
        const name = $('#editLangName').val().trim();
        const author = $('#editLangAuthor').val().trim();
        const version = $('#editLangVersion').val().trim();
        const iconPath = $('#editLangIcon').val().trim();
        const iconFile = $('#editLangIconFile')[0].files[0];
        
        if (!name) {
            showAlert('<?php echo $lang241; ?>', 'warning');
            return;
        }
        
        if (iconFile) {
            const formData = new FormData();
            formData.append('file', iconFile);
            formData.append('code', code);
            formData.append('plugin', pluginName);
            
            try {
                const uploadResponse = await fetch('lang_editor_api.php?action=upload_plugin_icon', {
                    method: 'POST',
                    body: formData
                });
                const uploadResult = await uploadResponse.json();
                if (uploadResult.success && uploadResult.icon_path) {
                    await updateLanguageSettings(code, name, author, version, uploadResult.icon_path);
                } else {
                    showAlert('<?php echo $lang242; ?> ' + (uploadResult.error || 'Unknown error'), 'danger');
                }
            } catch (error) {
                showAlert('<?php echo $lang243; ?> ' + error.message, 'danger');
            }
        } else {
            await updateLanguageSettings(code, name, author, version, iconPath);
        }
    }

    async function updateLanguageSettings(code, name, author, version, icon) {
        try {
            const response = await fetch('lang_editor_api.php?action=update_plugin_settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    code: code,
                    name: name,
                    author: author,
                    version: version,
                    icon: icon,
                    plugin: pluginName
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                showAlert('<?php echo $lang244; ?>', 'success');
                $('#editSettingsModal').modal('hide');
                setTimeout(() => window.location.reload(), 1000);
            } else {
                showAlert('<?php echo $lang245; ?> ' + result.error, 'danger');
            }
        } catch (error) {
            showAlert('<?php echo $lang246; ?> ' + error.message, 'danger');
        }
    }

    async function downloadLanguage(code) {
        try {
            const response = await fetch(`lang_editor_api.php?action=download_plugin_language&code=${encodeURIComponent(code)}&plugin=${encodeURIComponent(pluginName)}`);
            
            if (!response.ok) {
                throw new Error('<?php echo $lang247; ?>');
            }
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = code + '.php';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showAlert(`<?php echo $lang248; ?> ${code}.php <?php echo $lang249; ?>`, 'success');
        } catch (error) {
            showAlert('<?php echo $lang250; ?> ' + error.message, 'danger');
        }
    }

    async function createLanguage() {
        const code = $('#createLangCode').val().trim();
		const formattedCode = code.charAt(0).toUpperCase() + code.slice(1).toLowerCase();
        const name = $('#createLangName').val().trim();
        const author = $('#createLangAuthor').val().trim();
        const version = $('#createLangVersion').val().trim();
        const icon = $('#createLangIcon').val().trim();
        
        if (!code || !name) {
            showAlert('<?php echo $lang251; ?>', 'warning');
            return;
        }
        
        if (!/^[A-Za-z]{2}$/.test(code)) {
            showAlert('<?php echo $lang252; ?>', 'warning');
            return;
        }
        
        showAlert('<?php echo $lang253; ?>', 'info');
        
        try {
            const response = await fetch('lang_editor_api.php?action=create_plugin_language', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    code: code,
                    name: name,
                    author: author,
                    version: version,
                    icon: icon,
                    plugin: pluginName
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                showAlert(`<?php echo $lang254; ?> "${name}" <?php echo $lang255; ?>`, 'success');
                $('#createModal').modal('hide');
                setTimeout(() => {
                    window.location.href = `plugin_edit.php?plugin=${encodeURIComponent(pluginName)}&code=${code}`;
                }, 1000);
            } else {
                showAlert('<?php echo $lang256; ?> ' + result.error, 'danger');
            }
        } catch (error) {
            showAlert('<?php echo $lang257; ?> ' + error.message, 'danger');
        }
    }

    async function uploadLanguage() {
        const fileInput = document.getElementById('uploadFile');
        const file = fileInput.files[0];
        
        if (!file) {
            showAlert('<?php echo $lang258; ?>', 'warning');
            return;
        }
        
        if (!file.name.match(/^[A-Za-z]{2}\.php$/)) {
            showAlert('<?php echo $lang259; ?>', 'warning');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('plugin', pluginName);
        
        showAlert('<?php echo $lang260; ?>', 'info');
        
        try {
            const response = await fetch('lang_editor_api.php?action=upload_plugin_language', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showAlert('<?php echo $lang261; ?>', 'success');
                $('#uploadModal').modal('hide');
                setTimeout(() => window.location.reload(), 1000);
            } else {
                showAlert('<?php echo $lang262; ?> ' + result.error, 'danger');
            }
        } catch (error) {
            showAlert('<?php echo $lang263; ?> ' + error.message, 'danger');
        }
    }

    async function deleteLanguage(code, name) {
        if (!confirm(`<?php echo $lang264; ?> "${name}" (${code}.php)?\n\n<?php echo $lang265; ?>`)) {
            return;
        }
        
        showAlert('<?php echo $lang266; ?>', 'info');
        
        try {
            const response = await fetch('lang_editor_api.php?action=delete_plugin_language', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    code: code,
                    plugin: pluginName
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                showAlert(`<?php echo $lang267; ?> "${name}" <?php echo $lang268; ?>`, 'success');
                setTimeout(() => window.location.reload(), 1000);
            } else {
                showAlert('<?php echo $lang269; ?> ' + result.error, 'danger');
            }
        } catch (error) {
            showAlert('<?php echo $lang270; ?> ' + error.message, 'danger');
        }
    }

    function showAlert(message, type) {
        const icon = type === 'success' ? 'check-circle' : (type === 'danger' ? 'exclamation-triangle' : (type === 'warning' ? 'exclamation-triangle' : 'info-circle'));
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" style="position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; max-width: 500px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <i class="fas fa-${icon}"></i> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        $('#alertContainer').append(alertHtml);
        setTimeout(() => $('.alert').fadeOut(500, function() { $(this).remove(); }), 3000);
    }
    </script>
    </body>
    </html>
    <?php
    exit;
}

$lang_file = $lang_dir . $lang_code . '.php';

if (!file_exists($lang_file)) {
    header('Location: plugin_edit.php?plugin=' . urlencode($plugin));
    exit;
}

$content = file_get_contents($lang_file);

$metadata = [];
if (preg_match('/\$LANG_NAME\s*=\s*"([^"]+)"/', $content, $m)) $metadata['name'] = $m[1];
if (preg_match('/\$LANG_ICON\s*=\s*"([^"]+)"/', $content, $m)) $metadata['icon'] = $m[1];
if (preg_match('/\$LANG_AUTHOR\s*=\s*"([^"]+)"/', $content, $m)) $metadata['author'] = $m[1];
if (preg_match('/\$LANG_VERSION\s*=\s*"([^"]+)"/', $content, $m)) $metadata['version'] = $m[1];

$variables = [];
preg_match_all('/\$lang(\d+)\s*=\s*"([^"\\\\]*(?:\\\\.[^"\\\\]*)*)"/', $content, $matches, PREG_SET_ORDER);
foreach ($matches as $match) {
    $variables[] = [
        'key' => 'lang' . $match[1],
        'number' => (int)$match[1],
        'value' => stripslashes($match[2])
    ];
}

usort($variables, function($a, $b) {
    return $a['number'] - $b['number'];
});

$next_number = 1;
if (!empty($variables)) {
    $max_number = max(array_column($variables, 'number'));
    $next_number = $max_number + 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit <?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?> - Plugin Language Editor</title>
    <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../css/loader.css">
    <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            height: 100%;
            overflow: hidden;
        }
        
        .app-container {
            display: flex;
            height: calc(100vh - 60px);
            overflow: hidden;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            padding: 24px 32px;
            overflow: hidden;
            margin-left: 260px;
        }
        
        .search-bar {
            position: sticky;
            top: 0;
            z-index: 99;
            padding: 10px 0 15px 0;
            background: #f0f2f5;
            flex-shrink: 0;
        }
        
        .table-wrapper {
            flex: 1;
            overflow-y: auto;
            margin-bottom: 10px;
            background: white;
            border-radius: 12px;
        }
        
        .table-wrapper table {
            margin-bottom: 0;
        }
        
        .variables-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .variables-table thead {
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .variables-table th {
            background: #f8f9fa;
            padding: 12px 16px;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .variables-table td {
            padding: 12px 16px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }
        
        .variable-key {
            font-family: monospace;
            font-weight: 600;
            color: #007aff;
            background: #f0f0f0;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            transition: background 0.2s;
            user-select: all;
            display: inline-block;
        }
        .variable-key:hover {
            background: #d4e4ff;
        }
        .variable-key:active {
            background: #b3d0ff;
        }
        
        .variable-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: monospace;
            font-size: 13px;
            transition: all 0.2s;
        }
        .variable-input:focus {
            outline: none;
            border-color: #007aff;
            box-shadow: 0 0 0 2px rgba(0,122,255,0.1);
        }
        
        .copy-btn {
            padding: 4px 8px;
            font-size: 12px;
        }
        
        .save-status {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
        }
        
        .bottom-panel {
            flex-shrink: 0;
            background: white;
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 40px;
            margin-top: 10px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .bottom-panel .input-group {
            flex: 1;
            min-width: 200px;
        }
        
        .bottom-panel .copy-options {
            display: flex;
            gap: 15px;
            align-items: center;
            font-size: 13px;
            margin: 0 10px;
        }
        
        .bottom-panel .copy-options label {
            margin-bottom: 0;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .bottom-panel .copy-options input[type="radio"] {
            margin-right: 2px;
        }
        
        .bottom-panel .btn {
            white-space: nowrap;
        }
        
        .bottom-nav {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-shrink: 0;
        }
        
        .plugin-badge {
            background: #e3f2fd;
            color: #007aff;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
        }
        
        .table-wrapper::-webkit-scrollbar {
            width: 8px;
        }
        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        .table-wrapper::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .variables-table td {
                padding: 8px;
            }
            .bottom-panel {
                flex-direction: column;
                align-items: stretch;
            }
            .bottom-panel .copy-options {
                margin: 5px 0;
                justify-content: center;
            }
            .bottom-nav {
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div id="applePreloader" class="apple-preloader">
    <div class="apple-spinner"></div>
    <div class="apple-spinner-text"><?php echo $lang2; ?></div>
</div>

<div class="top-bar">
    <div class="top-bar-left">
        <h1><i class="fas fa-bucket"></i> Mini-B</h1>
    </div>
    <div class="top-bar-right">
        <h5 class="d-inline-block mb-0 ms-2">
            <i class="fas fa-puzzle-piece text-primary"></i>
            <span class="plugin-badge"><?php echo htmlspecialchars($plugin); ?></span>
            <i class="fas fa-edit text-primary"></i>
            <?php echo $lang271; ?> <?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>
            <small class="text-muted">(<?php echo $lang_code; ?>.php)</small>
        </h5>
        
        <button class="btn btn-secondary btn-sm me-2" onclick="window.location.href='plugin_edit.php?plugin=<?php echo urlencode($plugin); ?>'">
            <i class="fas fa-arrow-left"></i> <?php echo $lang272; ?>
        </button>
        
        <span id="saveStatus" class="save-status text-muted me-2 ms-2">
            <i class="fas fa-check-circle"></i> <?php echo $lang273; ?>
        </span>
        
        <button class="btn btn-success btn-sm me-2" onclick="showAddVariableModal()">
            <i class="fas fa-plus"></i> <?php echo $lang274; ?>
        </button>
        
        <button class="btn btn-primary btn-sm me-2" onclick="saveAll()">
            <i class="fas fa-save"></i> <?php echo $lang275; ?>
        </button>
        
        <button class="btn btn-secondary btn-sm" onclick="showSaveAsModal()">
            <i class="fas fa-copy"></i> <?php echo $lang276; ?>
        </button>
    </div>
</div>

<div class="app-container">
    <?php echo $menu; ?>
    
    <main class="main-content">
        <div id="alertContainer"></div>
        
        <div class="search-bar">
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
                <input type="text" class="form-control" id="searchInput" placeholder="<?php echo $lang277; ?>">
                <button class="btn btn-outline-secondary" onclick="clearSearch()">
                    <i class="fas fa-times"></i> <?php echo $lang278; ?>
                </button>
            </div>
        </div>
        
        <div class="variables-table">
            <div class="table-wrapper" id="tableWrapper">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th style="width: 150px"><?php echo $lang279; ?></th>
                            <th><?php echo $lang280; ?></th>
                            <th style="width: 120px"><?php echo $lang281; ?></th>
                        </tr>
                    </thead>
                    <tbody id="variablesBody">
                        <?php foreach ($variables as $var): ?>
                        <tr data-key="<?php echo $var['key']; ?>" data-number="<?php echo $var['number']; ?>">
                            <td>
                                <code class="variable-key" onclick="copyVariableName('<?php echo $var['key']; ?>')" title="Click to copy variable name">$<?php echo $var['key']; ?></code>
                            </td>
                            <td>
                                <input type="text" class="variable-input" data-key="<?php echo $var['key']; ?>" value="<?php echo htmlspecialchars($var['value']); ?>">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('<?php echo $var['key']; ?>')" title="<?php echo $lang282; ?>">
                                    <i class="fas fa-copy"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '<?php echo $var['key']; ?>')" title="<?php echo $lang283; ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (empty($variables)): ?>
            <div class="text-center text-muted py-5">
                <i class="fas fa-code fa-4x mb-3"></i>
                <p><?php echo $lang284; ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="bottom-panel">
            <div class="input-group">
                <input type="text" class="form-control" id="quickAddInput" placeholder="<?php echo $lang285; ?>" style="font-family: monospace;">
                <button class="btn btn-success" onclick="quickAddVariable()">
                    <i class="fas fa-plus"></i> <?php echo $lang286; ?>
                </button>
            </div>
            
            <div class="copy-options">
                <label>
                    <input type="radio" name="copyMode" value="php" checked>
                    <?php echo $lang287; ?>
                </label>
                <label>
                    <input type="radio" name="copyMode" value="html">
                    <?php echo $lang288; ?>
                </label>
                <label>
                    <input type="radio" name="copyMode" value="none">
                    <?php echo $lang289; ?>
                </label>
            </div>
            
            <div class="bottom-nav">
                <button class="btn btn-sm btn-outline-secondary" onclick="scrollToTop()" title="<?php echo $lang290; ?>">
                    <i class="fas fa-arrow-up"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" onclick="scrollToBottom()" title="<?php echo $lang291; ?>">
                    <i class="fas fa-arrow-down"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" onclick="window.location.href='plugin_edit.php?plugin=<?php echo urlencode($plugin); ?>'" title="<?php echo $lang292; ?>">
                    <i class="fas fa-list"></i>
                </button>
            </div>
        </div>
    </main>
</div>

<!-- Add Variable Modal -->
<div class="modal fade" id="addVariableModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="fas fa-plus"></i> <?php echo $lang293; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang294; ?></label>
                    <input type="text" class="form-control" id="newVarKey" readonly value="lang<?php echo $next_number; ?>">
                    <small class="text-muted"><?php echo $lang295; ?> <?php echo $next_number; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang296; ?></label>
                    <textarea class="form-control" id="newVarValue" rows="3" placeholder="<?php echo $lang297; ?>"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang298; ?></button>
                <button type="button" class="btn btn-success" onclick="addNewVariable()"><?php echo $lang299; ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Save As Modal -->
<div class="modal fade" id="saveAsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-copy"></i> <?php echo $lang300; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang301; ?> *</label>
                    <input type="text" class="form-control" id="newLangCode" placeholder="De, Fr, Es" maxlength="2" style="text-transform: uppercase;">
                    <small class="text-muted"><?php echo $lang302; ?></small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang303; ?> *</label>
                    <input type="text" class="form-control" id="newLangName" value="<?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang304; ?></label>
                    <input type="text" class="form-control" id="newLangAuthor" value="<?php echo htmlspecialchars($metadata['author'] ?? 'Mini-B'); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang305; ?></label>
                    <input type="text" class="form-control" id="newLangVersion" value="<?php echo htmlspecialchars($metadata['version'] ?? '1.0.0'); ?>">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang306; ?></button>
                <button type="button" class="btn btn-primary" onclick="saveAsLanguage()"><?php echo $lang307; ?></button>
            </div>
        </div>
    </div>
</div>

<script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
<script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="../../js/loader.js"></script>

<script>
let currentLangCode = '<?php echo $lang_code; ?>';
let currentPlugin = '<?php echo addslashes($plugin); ?>';

$(document).ready(function() {
    $('#searchInput').on('keyup', function() {
        const search = $(this).val().toLowerCase();
        
        $('#variablesBody tr').each(function() {
            const key = $(this).data('key').toLowerCase();
            const value = $(this).find('.variable-input').val().toLowerCase();
            
            if (key.includes(search) || value.includes(search)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    $(document).on('input', '.variable-input', function() {
        $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> Unsaved').removeClass('text-muted text-success').addClass('text-warning');
    });
    
    $('#quickAddInput').on('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            quickAddVariable();
        }
    });
    
    setTimeout(() => $('#applePreloader').fadeOut(500), 500);
    setTimeout(() => $('#quickAddInput').focus(), 600);
});

function clearSearch() {
    $('#searchInput').val('');
    $('#variablesBody tr').show();
}

function scrollToTop() {
    document.getElementById('tableWrapper').scrollTop = 0;
}

function scrollToBottom() {
    const wrapper = document.getElementById('tableWrapper');
    wrapper.scrollTop = wrapper.scrollHeight;
}

function scrollToLastRow() {
    const wrapper = document.getElementById('tableWrapper');
    const rows = $('#variablesBody tr');
    if (rows.length > 0) {
        const lastRow = rows[rows.length - 1];
        const rowTop = lastRow.offsetTop;
        const rowHeight = lastRow.offsetHeight;
        wrapper.scrollTop = rowTop - wrapper.offsetHeight + rowHeight + 20;
    }
}

function copyVariableName(key) {
    const fullName = '$' + key;
    
    navigator.clipboard.writeText(fullName).then(() => {
        showAlert('<?php echo $lang308; ?> <code>' + fullName + '</code>', 'success');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = fullName;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showAlert('<?php echo $lang309; ?> <code>' + fullName + '</code>', 'success');
    });
}

function quickAddVariable() {
    const input = $('#quickAddInput');
    const value = input.val();
    
    if (!value) {
        showAlert('<?php echo $lang310; ?>', 'warning');
        input.focus();
        return;
    }
    
    let maxNumber = 0;
    $('#variablesBody tr').each(function() {
        const num = parseInt($(this).data('number'));
        if (num > maxNumber) maxNumber = num;
    });
    const nextNumber = maxNumber + 1;
    const key = 'lang' + nextNumber;
    
    let exists = false;
    $('#variablesBody tr').each(function() {
        if ($(this).data('key') === key) {
            exists = true;
            return false;
        }
    });
    
    if (exists) {
        showAlert('<?php echo $lang311; ?>', 'danger');
        return;
    }
    
    const newRow = `
        <tr data-key="${escapeHtml(key)}" data-number="${nextNumber}">
            <td>
                <code class="variable-key" onclick="copyVariableName('${escapeHtml(key)}')" title="<?php echo $lang312; ?>">$${escapeHtml(key)}</code>
            </td>
            <td>
                <input type="text" class="variable-input" data-key="${escapeHtml(key)}" value="${escapeHtml(value)}">
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('${escapeHtml(key)}')" title="<?php echo $lang313; ?>">
                    <i class="fas fa-copy"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '${escapeHtml(key)}')" title="<?php echo $lang314; ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    
    $('#variablesBody').append(newRow);
    
    const copyMode = $('input[name="copyMode"]:checked').val();
    
    if (copyMode === 'php') {
        copyVariableName(key);
    } else if (copyMode === 'html') {
        copyVariable(key);
    }
    
    input.val('');
    input.focus();
    
    setTimeout(() => scrollToLastRow(), 100);
    
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang315; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang316; ?> ' + key + ' <?php echo $lang317; ?>', 'success');
}

function copyVariable(key) {
    const code = '<\?php echo $' + key + '; ?>';
    
    navigator.clipboard.writeText(code).then(() => {
        const displayCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        showAlert('<?php echo $lang318; ?> ' + displayCode, 'success');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = code;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        const displayCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        showAlert('<?php echo $lang319; ?> ' + displayCode, 'success');
    });
}

function deleteVariableRow(btn, key) {
    if (!confirm('<?php echo $lang320; ?> ' + key + '?')) return;
    
    $(btn).closest('tr').remove();
    
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang321; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang322; ?> ' + key + ' <?php echo $lang323; ?>', 'info');
}

function showAddVariableModal() {
    let maxNumber = 0;
    $('#variablesBody tr').each(function() {
        const num = parseInt($(this).data('number'));
        if (num > maxNumber) maxNumber = num;
    });
    const nextNumber = maxNumber + 1;
    
    $('#newVarKey').val('lang' + nextNumber);
    $('#newVarValue').val('');
    $('#addVariableModal').modal('show');
}

function addNewVariable() {
    const key = $('#newVarKey').val();
    const value = $('#newVarValue').val();
    const number = parseInt(key.replace('lang', ''));
    
    let exists = false;
    $('#variablesBody tr').each(function() {
        if ($(this).data('key') === key) {
            exists = true;
            return false;
        }
    });
    
    if (exists) {
        showAlert('<?php echo $lang324; ?>', 'danger');
        return;
    }
    
    const newRow = `
        <tr data-key="${escapeHtml(key)}" data-number="${number}">
            <td>
                <code class="variable-key" onclick="copyVariableName('${escapeHtml(key)}')" title="<?php echo $lang325; ?>">$${escapeHtml(key)}</code>
            </td>
            <td>
                <input type="text" class="variable-input" data-key="${escapeHtml(key)}" value="${escapeHtml(value)}">
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyVariable('${escapeHtml(key)}')" title="<?php echo $lang326; ?>">
                    <i class="fas fa-copy"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger copy-btn" onclick="deleteVariableRow(this, '${escapeHtml(key)}')" title="<?php echo $lang327; ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    
    $('#variablesBody').append(newRow);
    
    setTimeout(() => scrollToLastRow(), 100);
    
    $('#addVariableModal').modal('hide');
    $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang328; ?>').removeClass('text-muted text-success').addClass('text-warning');
    showAlert('<?php echo $lang329; ?> ' + key + ' <?php echo $lang330; ?>', 'success');
}

async function saveAll() {
    const variables = [];
    
    $('#variablesBody tr').each(function() {
        const key = $(this).data('key');
        const value = $(this).find('.variable-input').val();
        const number = parseInt(key.replace('lang', ''));
        variables.push({ key: key, number: number, value: value });
    });
    
    $('#saveStatus').html('<i class="fas fa-spinner fa-spin"></i> <?php echo $lang331; ?>').removeClass('text-warning text-muted').addClass('text-info');
    
    try {
        const response = await fetch('lang_editor_api.php?action=save_plugin_language', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                code: currentLangCode,
                plugin: currentPlugin,
                variables: JSON.stringify(variables)
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            $('#saveStatus').html('<i class="fas fa-check-circle"></i> <?php echo $lang332; ?>').removeClass('text-info').addClass('text-success');
            
            setTimeout(() => {
                $('#saveStatus').html('<i class="fas fa-check-circle"></i> <?php echo $lang333; ?>').removeClass('text-success').addClass('text-muted');
            }, 2000);
            
            showAlert('<?php echo $lang334; ?>', 'success');
            
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang335; ?>').removeClass('text-info').addClass('text-danger');
            showAlert('<?php echo $lang336; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        console.error('Save error:', error);
        $('#saveStatus').html('<i class="fas fa-exclamation-triangle"></i> <?php echo $lang337; ?>').removeClass('text-info').addClass('text-danger');
        showAlert('<?php echo $lang338; ?>', 'danger');
    }
}

function showSaveAsModal() {
    $('#newLangCode').val('');
    $('#newLangName').val('<?php echo htmlspecialchars($metadata['name'] ?? $lang_code); ?>');
    $('#newLangAuthor').val('<?php echo htmlspecialchars($metadata['author'] ?? 'Mini-B'); ?>');
    $('#newLangVersion').val('<?php echo htmlspecialchars($metadata['version'] ?? '1.0.0'); ?>');
    $('#saveAsModal').modal('show');
}

async function saveAsLanguage() {
    const newCode = $('#newLangCode').val().trim().toUpperCase();
    const newName = $('#newLangName').val().trim();
    const newAuthor = $('#newLangAuthor').val().trim();
    const newVersion = $('#newLangVersion').val().trim();
    
    if (!newCode || !newName) {
        showAlert('<?php echo $lang339; ?>', 'warning');
        return;
    }
    
    if (!/^[A-Z]{2}$/.test(newCode)) {
        showAlert('<?php echo $lang340; ?>', 'warning');
        return;
    }
    
    const variables = [];
    $('#variablesBody tr').each(function() {
        const key = $(this).data('key');
        const value = $(this).find('.variable-input').val();
        const number = parseInt(key.replace('lang', ''));
        variables.push({ number: number, value: value });
    });
    
    try {
        const response = await fetch('lang_editor_api.php?action=save_plugin_as', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                source_code: currentLangCode,
                new_code: newCode,
                new_name: newName,
                new_author: newAuthor,
                new_version: newVersion,
                plugin: currentPlugin,
                variables: JSON.stringify(variables)
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('<?php echo $lang341; ?> "' + newName + '"', 'success');
            $('#saveAsModal').modal('hide');
            window.location.href = 'plugin_edit.php?plugin=' + encodeURIComponent(currentPlugin) + '&code=' + newCode;
        } else {
            showAlert('<?php echo $lang342; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        showAlert('<?php echo $lang343; ?> ' + error.message, 'danger');
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function showAlert(message, type) {
    const icon = type === 'success' ? 'check-circle' : (type === 'danger' ? 'exclamation-triangle' : (type === 'warning' ? 'exclamation-triangle' : 'info-circle'));
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" style="position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; max-width: 500px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <i class="fas fa-${icon}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    $('#alertContainer').append(alertHtml);
    setTimeout(() => $('.alert').fadeOut(500, function() { $(this).remove(); }), 3000);
}
</script>
</body>
</html>