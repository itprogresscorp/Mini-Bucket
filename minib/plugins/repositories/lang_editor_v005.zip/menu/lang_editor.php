<?php return array (
  'enabled' => false,
  'group' => 'tools',
  'group_title' => 'tools',
  'title' => 'Langauge Editor',
  'url' => '/plugins/lang_editor/lang_editor.php',
  'icon' => 'fa fa-language',
);