#!/bin/bash

MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/lang_editor"
MINIB_DIR="/var/www/minib/plugins/installed/lang_editor"

rm -rf $ADMIN_DIR
rm -rf $MINIB_DIR
rm $MENU_DIR/lang_editor.php