<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Log manager Plugin" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */
require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();
require_once 'lang/loader.php';

$current_host_id = $_SESSION['current_host_id'] ?? 1;

try {
    $db = getDB();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}

// Получаем API ключ
$stmt = $db->prepare("SELECT idHost, hostName, hostApiKey, hostProto, hostIp, hostPort, hostApiPath FROM hosts WHERE idHost = :id");
$stmt->bindValue(':id', $current_host_id, SQLITE3_INTEGER);
$result = $stmt->execute();
$host = $result->fetchArray(SQLITE3_ASSOC);

if ($host) {
    $api_key = $host['hostApiKey'];
    $host_name = $host['hostName'];
    $host_id = $host['idHost'];
    $host_proto = $host['hostProto'];
    $host_ip = $host['hostIp'];
    $host_port = $host['hostPort'];
    $host_api_path = $host['hostApiPath'];
    
    // Базовый URL без API пути (для плагинов)
    $base_url = $host_proto . "://" . $host_ip;
    if (!empty($host_port) && $host_port != 0 && $host_port != '0') {
        $base_url .= ":" . $host_port;
    }
    // Полный URL с API путём (для остальных API вызовов)
    $host_url = $base_url . $host_api_path;
    
    if ($current_host_id == 1) {
    // Локальный хост
    $plugin_api_url = dirname($_SERVER['SCRIPT_NAME']) . '/log_manager_api.php';
    $system_api_url = '/api/';
} else {
    // Удалённый хост
    $base_url = $host_proto . "://" . $host_ip;
    if (!empty($host_port) && $host_port != 0 && $host_port != '0') {
        $base_url .= ":" . $host_port;
    }
    $plugin_api_url = rtrim($base_url, '/') . '/plugins/log_manager/log_manager_api.php';
    $system_api_url = rtrim($base_url, '/') . '/api/';
}
}
$js_config = [
    'pluginApiUrl' => $plugin_api_url,     // Для вызовов плагина
    'apiBaseUrl' => $system_api_url,       // Для crt_checker.js (системный)
    'apiKey' => $api_key,
    'isLocalhost' => ($current_host_id == 1),
    'currentHostId' => $current_host_id
];

$menu = require_once dirname(dirname(dirname(__FILE__))) . '/menu.php';

// Создаем БД если её нет (только для локального хоста)
define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/log_manager/');
$log_db_path = PLUGIN_BACKEND . '/log_manager.db';
if ($current_host_id == 1 && !file_exists($log_db_path)) {
    try {
        $log_db = new SQLite3($log_db_path);
        $log_db->exec("
            CREATE TABLE IF NOT EXISTS log_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                path TEXT NOT NULL UNIQUE,
                enabled INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        $log_db->close();
        chmod($log_db_path, 0666);
    } catch (Exception $e) {
        // Ошибка создания БД
    }
}


define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/log_manager/');
define('LOG_MANAGER_DB', PLUGIN_BACKEND . '/info.json');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Mini-B - Log Manager</title>
    <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../css/loader.css">
	<link rel="stylesheet" href="plugin.css">
    <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
    <script src="../../js/hosts_load.js"></script>
    <script src="../../js/crt_checker.js"></script>
    <script>
    window.apiConfig = <?php echo json_encode($js_config); ?>;
    //console.log('API Config loaded:', window.apiConfig);
    </script>
</head>
<body>
<div id="applePreloader" class="apple-preloader">
    <div class="apple-spinner"></div>
    <div class="apple-spinner-text"><?php echo $lang1; ?></div>
</div>

<div class="top-bar">
    <div class="top-bar-left">
        <h1><i class="fas fa-bucket"></i> Mini-B</h1>
    </div>
    <div class="top-bar-right">
        <div class="host-selector" style="margin-left: 20px;">
            <select id="hostSelector" style="background: rgba(255,255,255,0.9); border: 1px solid #ddd; border-radius: 20px; padding: 6px 30px 6px 15px; font-size: 14px; cursor: pointer;">
                <option value=""><?php echo $lang1; ?></option>
            </select>
        </div>
    </div>
</div>

<div class="app-container">
    <?php echo $menu; ?>
    
    <main class="main-content">
        <div id="alertContainer"></div>
        
        <div class="row">
            
            <div class="col-md-9">
                <div class="log-control-bar">
                    <div class="row align-items-center g-3">
                        <div class="col-md-auto">
                            <div class="form-check form-switch">
                                <input type="checkbox" id="liveToggle" class="form-check-input">
                                <label class="form-check-label" for="liveToggle">
                                    <i class="fas fa-sync-alt"></i> <?php echo $lang2; ?>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-auto">
                            <span id="liveIndicator" class="live-indicator live-inactive">
                                <i class="fas fa-pause"></i> <?php echo $lang3; ?>
                            </span>
                        </div>
                        <div class="col-md">
                            <div class="input-group search-input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="searchInput" class="form-control" placeholder="<?php echo $lang4; ?>">
                                <button class="btn btn-outline-secondary" id="clearSearchBtn" type="button">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-auto">
                            <div class="btn-group">
                                <button class="btn btn-outline-secondary btn-sm" id="refreshBtn" title="<?php echo $lang5; ?>">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <button class="btn btn-outline-secondary btn-sm" id="clearLogBtn" title="<?php echo $lang6; ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
								<button class="btn btn-outline-danger btn-sm" id="clearLogFileBtn" title="Clear Log File">
									<i class="fas fa-trash-alt"></i> <?php echo $lang7; ?>
								</button>
                                <div class="btn-group">
                                    <button class="btn btn-outline-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown">
                                        <i class="fas fa-download"></i> <?php echo $lang8; ?>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li><a class="dropdown-item" href="#" data-export="txt"><i class="fas fa-file-alt"></i> <?php echo $lang9; ?></a></li>
                                        <li><a class="dropdown-item" href="#" data-export="json"><i class="fas fa-code"></i> <?php echo $lang10; ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="widget">
                    <div class="widget-header">
                        <h3><i class="fas fa-file-alt text-primary"></i> <span id="currentLogName"><?php echo $lang11; ?></span></h3>
                        <span id="logFileInfo" class="file-info"></span>
                    </div>
                    <div class="widget-body p-0">
                        <div class="log-viewer-container">
                            <div class="log-viewer-content" id="logViewer">
                                <div class="text-center py-5 text-muted">
                                    <i class="fas fa-file-alt fa-3x mb-3 d-block"></i>
                                    <?php echo $lang12; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<div class="col-md-3">
                <div class="widget">
                    <div class="widget-header">
                        <h3><i class="fas fa-list text-primary"></i> <?php echo $lang13; ?></h3>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addSourceModal">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    <div class="widget-body p-0">
                        <div id="sourcesList" class="list-group list-group-flush">
                            <div class="text-center py-4"><div class="loading-spinner-sm"></div> <?php echo $lang14; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Modal: Add Log Source -->
<div class="modal fade" id="addSourceModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-plus-circle"></i> <?php echo $lang15; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="addSourceForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang16; ?> *</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g.: Nginx Access Log">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang17; ?> *</label>
                        <div class="input-group">
                            <input type="text" name="path" id="sourcePath" class="form-control" required placeholder="/var/log/...">
                            <button type="button" class="btn btn-secondary" onclick="openFileBrowser()">
                                <i class="fas fa-folder-open"></i> <?php echo $lang18; ?>
                            </button>
                        </div>
                        <small class="text-muted"><?php echo $lang19; ?></small>
                    </div>
                    <div class="mb-3">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            <?php echo $lang20; ?>
                            <div id="suggestedLogs" class="mt-2"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang21; ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo $lang22; ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: File Browser -->
<div class="modal fade" id="fileBrowserModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-folder-open"></i> <?php echo $lang23; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang24; ?></label>
                    <div class="input-group">
                        <input type="text" id="browseCurrentPath" class="form-control" value="/var/log" readonly>
                        <button class="btn btn-outline-secondary" onclick="refreshCurrentDirectory()">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                        <button class="btn btn-outline-secondary" onclick="goToParentDirectory()">
                            <i class="fas fa-level-up-alt"></i> <?php echo $lang25; ?>
                        </button>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang26; ?></label>
                    <div class="input-group">
                        <input type="text" id="customPath" class="form-control" placeholder="/var/log/nginx">
                        <button class="btn btn-primary" onclick="goToCustomPath()">
                            <i class="fas fa-folder-open"></i> <?php echo $lang27; ?>
                        </button>
                    </div>
                </div>
                <div id="fileBrowserList" style="max-height: 400px; overflow-y: auto;">
                    <div class="text-center py-3"><div class="loading-spinner-sm"></div> <?php echo $lang28; ?></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang29; ?></button>
                <button type="button" class="btn btn-primary" onclick="selectFile()"><?php echo $lang30; ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Edit Source -->
<div class="modal fade" id="editSourceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title"><i class="fas fa-edit"></i> <?php echo $lang31; ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editSourceForm">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang32; ?></label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang33; ?></label>
                        <input type="text" name="path" id="edit_path" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang34; ?></button>
                    <button type="submit" class="btn btn-warning"><?php echo $lang35; ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
<script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="../../js/loader.js"></script>
<script>
// Определяем базовый URL для API плагина
const pluginUrl = "<?php echo dirname($_SERVER['SCRIPT_NAME']); ?>/";
let currentSourceId = null;
let liveMode = false;
let liveInterval = null;
let currentSearchTerm = '';
let currentLogLines = [];
let selectedFilePath = '';

// ========== ПРОВЕРКА ПЛАГИНА НА УДАЛЁННОМ СЕРВЕРЕ ==========
let remotePluginAvailable = true;
let pendingAction = null;

/**
 * Проверка доступности плагина на удалённом сервере
 */
async function checkRemotePluginAvailability() {
    if (window.apiConfig.isLocalhost) {
        return true;
    }
    
    try {
        // Правильный путь к API плагина на удалённом сервере
        const pluginApiUrl = `${window.apiConfig.apiBaseUrl}../plugins/log_manager/log_manager_api.php`;
        
        console.log('Checking remote plugin at:', pluginApiUrl);
        
        const response = await fetch(`${pluginApiUrl}?action=get_plugin_status`, {
            method: 'GET',
            headers: { 'X-API-Key': window.apiConfig.apiKey || '' }
        });
        
        if (!response.ok) {
            console.log('Plugin check response not OK:', response.status);
            return false;
        }
        
        const result = await response.json();
        console.log('Plugin check result:', result);
        
        return result.success === true;
    } catch (error) {
        console.error('Plugin check failed:', error);
        return false;
    }
}

/**
 * Показать модальное окно установки плагина
 */
function showPluginInstallModal(callback) {
    // Сохраняем действие, которое нужно выполнить после установки
    pendingAction = callback;
    
    // Создаём модальное окно
    const modalHtml = `
        <div class="modal fade" id="pluginInstallModal" tabindex="-1" data-bs-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title">
                            <i class="fas fa-puzzle-piece"></i> <?php echo $lang36; ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-4">
                            <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
                            <h6><?php echo $lang37; ?></h6>
                            <p class="text-muted"><?php echo $lang38; ?></p>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong><?php echo $lang39; ?></strong><br>
                            <?php echo $lang40; ?>
                            <?php echo $lang41; ?>
                        </div>
                        <div id="installProgress" style="display: none;">
                            <div class="progress mb-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                     style="width: 0%">0%</div>
                            </div>
                            <p class="text-center small text-muted" id="installStatus"><?php echo $lang42; ?></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times"></i> <?php echo $lang43; ?>
                        </button>
                        <button type="button" class="btn btn-primary" id="confirmInstallBtn">
                            <i class="fas fa-download"></i> <?php echo $lang44; ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#pluginInstallModal').remove();
    $('body').append(modalHtml);
    
    const modal = new bootstrap.Modal(document.getElementById('pluginInstallModal'));
    modal.show();
    
    // Обработчик установки
    $('#confirmInstallBtn').off('click').on('click', async function() {
        await installRemotePlugin();
    });
}

/**
 * Установка плагина на удалённый сервер
 */
async function installRemotePlugin() {
    const installBtn = $('#confirmInstallBtn');
    const progressDiv = $('#installProgress');
    const progressBar = $('.progress-bar');
    const statusText = $('#installStatus');
    
    installBtn.prop('disabled', true);
    installBtn.html('<span class="loading-spinner-sm"></span> <?php echo $lang45; ?>');
    progressDiv.show();
    
    try {
        // 1. Находим ZIP плагина в ЛОКАЛЬНОМ репозитории
        statusText.text('<?php echo $lang46; ?>');
        progressBar.css('width', '30%');
        
        // Используем ЛОКАЛЬНЫЙ API для получения списка репозитория
        const repoResponse = await fetch('/api/plugins_api.php?action=get_repository', {
            headers: {
                'X-API-Key': window.apiConfig.apiKey || ''
            }
        });
        const repoData = await repoResponse.json();
        
        if (!repoData.success || !repoData.data) {
            throw new Error('<?php echo $lang47; ?>');
        }
        
        console.log('Local repository plugins:', repoData.data);
        
        // Ищем плагин log_manager по sysname
        let pluginZip = null;
        for (const plugin of repoData.data) {
            if (plugin.info && plugin.info.sysname === 'log_manager') {
                pluginZip = plugin;
                break;
            }
        }
        
        if (!pluginZip) {
            throw new Error('<?php echo $lang48; ?> /var/www/minib/plugins/repositories/');
        }
        
        statusText.text(`<?php echo $lang49; ?> ${pluginZip.filename}`);
        progressBar.css('width', '50%');
        
        // 2. Скачиваем ZIP с ЛОКАЛЬНОГО сервера
        statusText.text('<?php echo $lang50; ?>');
        
        const zipResponse = await fetch(`/api/plugins_api.php?action=download_plugin_zip&filename=${encodeURIComponent(pluginZip.filename)}`, {
            headers: {
                'X-API-Key': window.apiConfig.apiKey || ''
            }
        });
        
        if (!zipResponse.ok) {
            throw new Error('<?php echo $lang51; ?>');
        }
        
        const zipBlob = await zipResponse.blob();
        const formData = new FormData();
        formData.append('plugin_file', zipBlob, pluginZip.filename);
        
        // 3. Отправляем на УДАЛЁННЫЙ сервер для установки
        statusText.text('<?php echo $lang52; ?>');
        progressBar.css('width', '75%');
        
        const installUrl = `${window.apiConfig.apiBaseUrl}plugin_remote_installer.php?action=install_plugin`;
        
        const installResponse = await fetch(installUrl, {
            method: 'POST',
            headers: {
                'X-API-Key': window.apiConfig.apiKey || ''
            },
            body: formData
        });
        
        const installResult = await installResponse.json();
        
        if (!installResult.success) {
            throw new Error(installResult.error || 'Installation failed');
        }
        
        statusText.text('<?php echo $lang53; ?>');
        progressBar.css('width', '100%');
        
        showAlert('<?php echo $lang54; ?>', 'success');
        
        setTimeout(() => {
            $('#pluginInstallModal').modal('hide');
            location.reload();
        }, 1500);
        
    } catch (error) {
        console.error('Installation error:', error);
        showAlert('<?php echo $lang55; ?> ' + error.message, 'danger');
        
        statusText.html(`<span class="text-danger"><?php echo $lang56; ?> ${escapeHtml(error.message)}</span>`);
        installBtn.prop('disabled', false);
        installBtn.html('<i class="fas fa-download"></i> <?php echo $lang57; ?>');
        progressDiv.hide();
    }
}

/**
 * Получение ZIP файла плагина из репозитория
 */
async function downloadPluginZip(filename) {
    const response = await fetch(`${window.apiConfig.apiBaseUrl}plugins_api.php?action=download_plugin_zip&filename=${encodeURIComponent(filename)}`, {
        headers: {
            'X-API-Key': window.apiConfig.apiKey || ''
        }
    });
    
    if (!response.ok) {
        throw new Error('<?php echo $lang58; ?>');
    }
    
    return response.blob();
}

// Функция для выполнения API запросов к ПЛАГИНУ
async function apiCall(action, method = 'GET', data = null) {
    // Определяем, какой API файл использовать
    const pluginActions = ['send_plugin_to_remote', 'check_remote_plugin', 'get_repository', 'install_from_repository', 'upload_plugin', 'delete_repository_zip'];
    
    let baseUrl;
    if (pluginActions.includes(action)) {
        // Для операций с плагинами используем api/plugins_api.php
        baseUrl = window.apiConfig.apiBaseUrl + 'plugins_api.php';
        console.log('Using plugins_api.php for action:', action);
    } else {
        // Для операций с логами используем log_manager_api.php
        baseUrl = window.apiConfig.pluginApiUrl;
        console.log('Using log_manager_api.php for action:', action);
    }
    
    let fullUrl;
    if (method === 'GET' && data) {
        fullUrl = `${baseUrl}?action=${action}&${new URLSearchParams(data)}`;
    } else {
        fullUrl = `${baseUrl}?action=${action}`;
    }
    
    let options = { 
        method: method, 
        headers: {
            'X-API-Key': window.apiConfig.apiKey || ''
        }
    };
    
    if (method === 'POST' && data) {
        options.headers['Content-Type'] = 'application/x-www-form-urlencoded';
        options.body = new URLSearchParams(data);
    }
    
    try {
        console.log('API Call:', fullUrl, options);
        let response = await fetch(fullUrl, options);
        let result = await response.json();
        console.log('API Response:', result);
        return result;
    } catch(e) {
        console.error('API Error:', e);
        return { success: false, error: e.message };
    }
}

function showAlert(message, type = 'success') {
    const alertHtml = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i> 
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>`;
    $('#alertContainer').append(alertHtml);
    setTimeout(() => $('.alert').fadeOut(500, function() { $(this).remove(); }), 5000);
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m];
    });
}

function highlightSearch(text, searchTerm) {
    if (!searchTerm) return escapeHtml(text);
    const escapedText = escapeHtml(text);
    const escapedSearch = escapeHtml(searchTerm);
    const regex = new RegExp(`(${escapedSearch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return escapedText.replace(regex, '<span class="search-highlight">$1</span>');
}

async function loadSources() {
    let result = await apiCall('get_sources');
    if (result.success) {
        let sources = result.data;
        if (sources.length === 0) {
            $('#sourcesList').html('<div class="text-center py-4 text-muted"><i class="fas fa-folder-open fa-2x mb-2 d-block"></i><?php echo $lang59; ?></div>');
        } else {
            let html = '';
            sources.forEach(s => {
                let statusClass = s.exists ? (s.readable ? 'status-exists' : 'status-readable') : 'status-missing';
                let statusTitle = s.exists ? (s.readable ? '<?php echo $lang60; ?>' : '<?php echo $lang61; ?>') : '<?php echo $lang62; ?>';
                let disabledClass = s.enabled ? '' : 'disabled';
                let activeClass = (currentSourceId == s.id) ? 'active' : '';
                
                html += `
                    <div class="list-group-item list-group-item-action source-card ${activeClass} ${disabledClass}" data-id="${s.id}" data-enabled="${s.enabled}">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1" onclick="selectSource(${s.id})">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="status-badge ${statusClass}" title="${statusTitle}"></span>
                                    <strong>${escapeHtml(s.name)}</strong>
                                    ${!s.enabled ? '<span class="badge bg-secondary ms-2"><?php echo $lang63; ?></span>' : ''}
                                </div>
                                <small class="text-muted d-block">${escapeHtml(s.path)}</small>
                                <div class="file-info mt-1">
                                    ${s.exists ? (s.size ? (s.size/1024).toFixed(1) + ' KB' : '0 B') : '<?php echo $lang64; ?>'}
                                </div>
                            </div>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-sm btn-outline-warning" onclick="editSource(${s.id}, '${escapeHtml(s.name)}', '${escapeHtml(s.path)}')">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteSource(${s.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
            $('#sourcesList').html(html);
        }
    } else {
        $('#sourcesList').html('<div class="text-center py-4 text-danger"><?php echo $lang65; ?> ' + escapeHtml(result.error) + '</div>');
    }
}

async function selectSource(id) {
    currentSourceId = id;
    loadSources();
    await loadLogContent();
}

async function loadLogContent() {
    if (!currentSourceId) return;
    
    let params = { id: currentSourceId, lines: 500 };
    if (currentSearchTerm) {
        params.search = currentSearchTerm;
    }
    
    let result = await apiCall('get_log', 'GET', params);
    
    if (result.success) {
        currentLogLines = result.content;
        displayLogs(result.content);
        $('#currentLogName').text('Log Viewer');
        
        let sizeInfo = result.file_size ? (result.file_size/1024).toFixed(1) + ' KB' : '0 B';
        let dateInfo = result.file_mtime ? new Date(result.file_mtime * 1000).toLocaleString() : 'Unknown';
        $('#logFileInfo').html(`<i class="fas fa-database"></i> ${sizeInfo} | <i class="far fa-clock"></i> ${dateInfo} | <i class="fas fa-code-branch"></i> ${result.total_lines} <?php echo $lang66; ?>`);
        
        if (result.total_lines === 0 && currentSearchTerm) {
            showAlert('<?php echo $lang67; ?>', 'warning');
        }
    } else {
        showAlert('<?php echo $lang68; ?> ' + result.error, 'danger');
        $('#logViewer').html(`<div class="text-center py-5 text-danger"><i class="fas fa-exclamation-triangle fa-3x mb-3 d-block"></i>${escapeHtml(result.error)}</div>`);
    }
}

function displayLogs(lines) {
    if (!lines || lines.length === 0) {
        $('#logViewer').html('<div class="text-center py-5 text-muted"><i class="fas fa-inbox fa-3x mb-3 d-block"></i>No log entries</div>');
        return;
    }
    
    let html = '';
    lines.forEach((line, index) => {
        let displayLine = highlightSearch(line, currentSearchTerm);
        html += `<div class="log-line" data-line="${index}">${displayLine}</div>`;
    });
    
    $('#logViewer').html(html);
    $('#logViewer').scrollTop($('#logViewer')[0].scrollHeight);
}

function clearLogView() {
    $('#logViewer').html('<div class="text-center py-5 text-muted"><i class="fas fa-trash-alt fa-3x mb-3 d-block"></i><?php echo $lang70; ?></div>');
    currentLogLines = [];
}

async function addSource(data) {
    let result = await apiCall('add_source', 'POST', data);
    if (result.success) {
        showAlert('<?php echo $lang71; ?>', 'success');
        $('#addSourceModal').modal('hide');
        loadSources();
        $('#addSourceForm')[0].reset();
    } else {
        showAlert('<?php echo $lang72; ?> ' + result.error, 'danger');
    }
}

async function updateSource(data) {
    let result = await apiCall('update_source', 'POST', data);
    if (result.success) {
        showAlert('<?php echo $lang73; ?>', 'success');
        $('#editSourceModal').modal('hide');
        loadSources();
        if (currentSourceId == data.id) {
            await loadLogContent();
        }
    } else {
        showAlert('<?php echo $lang74; ?> ' + result.error, 'danger');
    }
}

async function deleteSource(id) {
    if (!confirm('<?php echo $lang75; ?>')) return;
    let result = await apiCall('delete_source', 'POST', { id: id });
    if (result.success) {
        showAlert('<?php echo $lang76; ?>', 'success');
        if (currentSourceId == id) {
            currentSourceId = null;
            $('#currentLogName').text('<?php echo $lang77; ?>');
            $('#logViewer').html('<div class="text-center py-5 text-muted"><i class="fas fa-file-alt fa-3x mb-3 d-block"></i><?php echo $lang78; ?></div>');
        }
        loadSources();
    } else {
        showAlert('<?php echo $lang79; ?>', 'danger');
    }
}

function editSource(id, name, path) {
    $('#edit_id').val(id);
    $('#edit_name').val(name);
    $('#edit_path').val(path);
    $('#editSourceModal').modal('show');
}

async function scanDirectory(dir) {
    $('#fileBrowserList').html('<div class="text-center py-3"><div class="loading-spinner-sm"></div> <?php echo $lang80; ?></div>');
    
    let result = await apiCall('scan_logs', 'GET', { directory: dir });
    
    if (result.success) {
        let items = result.items;
        let currentPath = result.current_path;
        
        $('#browseCurrentPath').val(currentPath);
        
        if (!items || items.length === 0) {
            $('#fileBrowserList').html('<div class="text-center py-3 text-muted"><?php echo $lang81; ?></div>');
            return;
        }
        
        let html = '<div class="list-group">';
        
        items.forEach(item => {
            if (item.type === 'directory') {
                html += `
                    <div class="list-group-item list-group-item-action directory-item" onclick="scanDirectory('${item.path.replace(/'/g, "\\'")}')" style="cursor: pointer;">
                        <i class="fas fa-folder text-warning"></i>
                        <strong>${escapeHtml(item.name)}/</strong>
                        <br><small class="text-muted">${escapeHtml(item.path)}</small>
                        <div class="file-info mt-1">
                            <i class="far fa-calendar-alt"></i> ${escapeHtml(item.modified)}
                        </div>
                    </div>
                `;
            } else {
                let sizeKB = (item.size / 1024).toFixed(1);
                html += `
                    <div class="list-group-item list-group-item-action directory-item" onclick="selectLogFile('${item.path.replace(/'/g, "\\'")}')" style="cursor: pointer;">
                        <i class="fas fa-file-alt text-primary"></i>
                        <strong>${escapeHtml(item.name)}</strong>
                        <br><small class="text-muted">${escapeHtml(item.path)}</small>
                        <div class="file-info mt-1">
                            <i class="fas fa-database"></i> ${sizeKB} KB | 
                            <i class="far fa-calendar-alt"></i> ${escapeHtml(item.modified)}
                        </div>
                    </div>
                `;
            }
        });
        
        html += '</div>';
        $('#fileBrowserList').html(html);
    } else {
        $('#fileBrowserList').html('<div class="alert alert-danger"><?php echo $lang82; ?> ' + escapeHtml(result.error || 'Unknown error') + '</div>');
    }
}

function refreshCurrentDirectory() {
    let currentPath = $('#browseCurrentPath').val();
    if (currentPath) {
        scanDirectory(currentPath);
    }
}

function goToParentDirectory() {
    let currentPath = $('#browseCurrentPath').val();
    if (currentPath && currentPath !== '/') {
        let parentPath = currentPath.substring(0, currentPath.lastIndexOf('/'));
        if (parentPath === '') parentPath = '/';
        scanDirectory(parentPath);
    }
}

function goToCustomPath() {
    let customPath = $('#customPath').val();
    if (customPath) {
        scanDirectory(customPath);
    } else {
        showAlert('<?php echo $lang83; ?>', 'warning');
    }
}

function openFileBrowser() {
    selectedFilePath = '';
    $('#customPath').val('');
    scanDirectory('/var/log');
    $('#fileBrowserModal').modal('show');
}

function selectLogFile(path) {
    selectedFilePath = path;
    $('#sourcePath').val(path);
    $('#fileBrowserModal').modal('hide');
    showAlert('<?php echo $lang84; ?> ' + path, 'success');
}

function selectFile() {
    if (selectedFilePath) {
        $('#sourcePath').val(selectedFilePath);
        $('#fileBrowserModal').modal('hide');
    } else {
        showAlert('<?php echo $lang85; ?>', 'warning');
    }
}

async function exportLog(format) {
    if (!currentSourceId) {
        showAlert('<?php echo $lang86; ?>', 'warning');
        return;
    }
    
    let baseUrl = window.apiConfig.apiBaseUrl;
    window.location.href = `${baseUrl}?action=export_log&id=${currentSourceId}&format=${format}`;
}

function startLiveMode() {
    if (liveInterval) clearInterval(liveInterval);
    liveInterval = setInterval(async () => {
        if (liveMode && currentSourceId) {
            await loadLogContent();
        }
    }, 3000);
    $('#liveIndicator').removeClass('live-inactive').addClass('live-active').html('<i class="fas fa-sync-alt fa-fw pulse"></i> <?php echo $lang87; ?>');
}

function stopLiveMode() {
    if (liveInterval) {
        clearInterval(liveInterval);
        liveInterval = null;
    }
    $('#liveIndicator').removeClass('live-active').addClass('live-inactive').html('<i class="fas fa-pause"></i> <?php echo $lang88; ?>');
}

let searchTimeout;
$('#searchInput').on('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        currentSearchTerm = $(this).val();
        if (currentSourceId) {
            loadLogContent();
        }
    }, 500);
});

$('#clearSearchBtn').on('click', function() {
    $('#searchInput').val('');
    currentSearchTerm = '';
    if (currentSourceId) {
        loadLogContent();
    }
});

$('#refreshBtn').on('click', function() {
    if (currentSourceId) {
        loadLogContent();
        showAlert('<?php echo $lang89; ?>', 'success');
    }
});

$('#clearLogBtn').on('click', function() {
    clearLogView();
});

$('#liveToggle').on('change', function() {
    liveMode = $(this).prop('checked');
    if (liveMode) {
        startLiveMode();
        showAlert('<?php echo $lang90; ?>', 'success');
    } else {
        stopLiveMode();
        showAlert('<?php echo $lang91; ?>', 'info');
    }
});

$('#addSourceForm').on('submit', function(e) {
    e.preventDefault();
    let data = $(this).serialize();
    addSource(data);
});

$('#editSourceForm').on('submit', function(e) {
    e.preventDefault();
    let data = $(this).serialize();
    updateSource(data);
});

$('[data-export="txt"]').on('click', function(e) {
    e.preventDefault();
    exportLog('txt');
});

$('[data-export="json"]').on('click', function(e) {
    e.preventDefault();
    exportLog('json');
});

$('#clearLogFileBtn').on('click', function() {
    clearLogFile();
});

async function clearLogFile() {
    if (!currentSourceId) {
        showAlert('<?php echo $lang92; ?>', 'warning');
        return;
    }
    
    const confirmed = confirm('⚠️ <?php echo $lang93; ?>\n\n' +
                             '<?php echo $lang94; ?>');
    
    if (!confirmed) return;
    
    const secondConfirm = confirm('<?php echo $lang95; ?>');
    
    if (!secondConfirm) return;
    
    const clearBtn = $('#clearLogFileBtn');
    const originalHtml = clearBtn.html();
    clearBtn.prop('disabled', true);
    clearBtn.html('<span class="loading-spinner-sm"></span> <?php echo $lang96; ?>');
    
    try {
        const result = await apiCall('clear_log_file', 'POST', { id: currentSourceId });
        
        if (result.success) {
            showAlert('✅ <?php echo $lang97; ?>', 'success');
            await loadLogContent();
        } else {
            showAlert('❌ <?php echo $lang98; ?> ' + result.error, 'danger');
        }
    } catch (error) {
        console.error('Clear log file error:', error);
        showAlert('<?php echo $lang99; ?> ' + error.message, 'danger');
    } finally {
        clearBtn.prop('disabled', false);
        clearBtn.html(originalHtml);
    }
}

function loadSuggestedLogs() {
    let suggested = [
        { name: 'vsftpd.log', path: '/var/log/vsftpd.log' },
        { name: 'syslog', path: '/var/log/syslog' },
        { name: 'auth.log', path: '/var/log/auth.log' },
        { name: 'nginx/access.log', path: '/var/log/nginx/access.log' },
        { name: 'nginx/error.log', path: '/var/log/nginx/error.log' },
        { name: 'mysql/error.log', path: '/var/log/mysql/error.log' }
    ];
    
    let html = '';
    suggested.forEach(log => {
        html += `<button type="button" class="btn btn-sm btn-outline-secondary m-1" onclick="$('#sourcePath').val('${log.path}'); showAlert('Selected: ${log.name}', 'info')">
            <i class="fas fa-file-alt"></i> ${escapeHtml(log.name)}
        </button>`;
    });
    $('#suggestedLogs').html(html);
}

$(document).ready(async function() {
    // Ждём загрузки конфигурации API
    if (window.apiConfig && window.apiConfig.apiBaseUrl) {
        console.log('API Base URL:', window.apiConfig.apiBaseUrl);
        
        // Проверяем доступность плагина на удалённом сервере
        const pluginAvailable = await checkRemotePluginAvailability();
        remotePluginAvailable = pluginAvailable;
        
        if (!pluginAvailable && !window.apiConfig.isLocalhost) {
            // Показываем модальное окно с предложением установить плагин
            showPluginInstallModal(() => {
                // После установки перезагружаем страницу
                location.reload();
            });
        } else {
            // Плагин доступен, загружаем источники
            loadSources();
        }
    } else {
        console.error('API Config not loaded properly');
        $('#sourcesList').html('<div class="text-center py-4 text-danger"><?php echo $lang100; ?></div>');
    }
    
    loadSuggestedLogs();
    
    setTimeout(function() {
        $('#applePreloader').fadeOut(500);
    }, 500);
});

$(window).on('beforeunload', function() {
    if (liveInterval) {
        clearInterval(liveInterval);
    }
});
</script>
</body>
</html>