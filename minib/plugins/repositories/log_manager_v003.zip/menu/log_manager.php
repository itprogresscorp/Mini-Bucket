<?php return array (
  'enabled' => false,
  'group' => 'tools',
  'group_title' => 'tools',
  'title' => 'Log Manager',
  'url' => '/plugins/log_manager/log_manager.php',
  'icon' => 'fas fa-file',
);