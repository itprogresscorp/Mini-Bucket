#!/bin/bash

# Patch
MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/log_manager"
MINIB_DIR="/var/www/minib/plugins/installed/log_manager"

# Creating folder
mkdir -p $ADMIN_DIR
mkdir -p $MINIB_DIR

# Permissions
chown -R www-data:www-data $ADMIN_DIR
chown -R www-data:www-data $MINIB_DIR
chmod -R 755 $ADMIN_DIR
chmod -R 755 $MINIB_DIR
chmod +x uninstall.sh

# Copy file to admin
cp -p log_manager.php $ADMIN_DIR/
cp -p log_manager_api.php $ADMIN_DIR/
cp -p plugin.css $ADMIN_DIR/
cp -p menu/log_manager.php $MENU_DIR/

# copy file to minib
cp -p install.php $MINIB_DIR/
cp -p info.json $MINIB_DIR/
cp -p uninstall.sh $MINIB_DIR/

# run install db
php $MINIB_DIR/install.php
chown www-data:www-data $MINIB_DIR/log_manager.db
chmod 755 $MINIB_DIR/log_manager.db

# deleting tmp folder
rm -rf /var/www/minib/plugins/extract/log_manager*
