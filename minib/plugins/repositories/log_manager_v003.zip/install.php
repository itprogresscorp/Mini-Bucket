<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Log manager Plugin" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));

if (file_exists(ROOT_PATH . '/config.php')) {
    require_once ROOT_PATH . '/config.php';
}

define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/log_manager/');
$dbPath = PLUGIN_BACKEND . '/log_manager.db';

try {
    $db = new SQLite3($dbPath);
    
    // Таблица для хранения источников логов
    $db->exec("
        CREATE TABLE IF NOT EXISTS log_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            path TEXT NOT NULL UNIQUE,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    
    // Таблица для кэша логов (опционально)
    $db->exec("
        CREATE TABLE IF NOT EXISTS log_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id INTEGER,
            content TEXT,
            line_count INTEGER,
            file_size INTEGER,
            file_mtime INTEGER,
            cached_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (source_id) REFERENCES log_sources(id) ON DELETE CASCADE
        )
    ");
    
    // Добавляем стандартные логи
    $check = $db->querySingle("SELECT COUNT(*) FROM log_sources");
    if ($check == 0) {
        $defaultLogs = [
            ['System Log', '/var/log/syslog'],
            ['Auth Log', '/var/log/auth.log'],
            ['MySQL Error', '/var/log/mysql/error.log'],
			['Mini-B WEB Error', '/var/www/minib/logs/web/admin_error.log'],
			['Mini-B WEB Access', '/var/www/minib/logs/web/admin_access.log'],
			['Mini-B API Inspector', '/var/www/minib/logs/api_inspector.log'],
			['Mini-B API Auto Rotation', '/var/www/minib/logs/auto_rotation.log'],
			['Mini-B API KEY Rotation', '/var/www/minib/logs/key_rotation.log'],
			['Mini-B Cron API Auto Rotation', '/var/www/minib/logs/cron_autorotate_key.log'],
			['Mini-B Cron API KEY Rotation', '/var/www/minib/logs/cron_key_rotation.log'],
			['Mini-B Disk Manager', '/var/www/minib/logs/disk_manager.log'],
			['Mini-B Download', '/var/www/minib/logs/download_log.txt'],
			['Mini-B Last Update', '/var/www/minib/logs/last_update.txt'],
			['Mini-B Mount Master', '/var/www/minib/logs/mount_master.log'],
        ];
        
        $stmt = $db->prepare("INSERT INTO log_sources (name, path) VALUES (:name, :path)");
        foreach ($defaultLogs as $log) {
            if (file_exists($log[1])) {
                $stmt->bindValue(':name', $log[0], SQLITE3_TEXT);
                $stmt->bindValue(':path', $log[1], SQLITE3_TEXT);
                $stmt->execute();
                $stmt->reset();
            }
        }
    }
    
    $db->close();
    
    echo "Database created successfully at: " . $dbPath . "\n";
    
} catch (Exception $e) {
    echo "Error creating database: " . $e->getMessage() . "\n";
}
?>