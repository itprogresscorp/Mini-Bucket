<?php
/*
 * Copyright (C) 2026 Mamontov Roman Igorevich
 *
 * This file is part of "Log manager Plugin" for Mini-Bucket - NAS Control Panel.
 *
 * Mini-Bucket - NAS Control Panel is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version, with the plugin exception (see LICENSE file).
 * Commercial use requires purchasing a separate commercial license from the copyright holder.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * https://mini-bucket.ru/
 */

if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));
}

if (file_exists(ROOT_PATH . '/config.php')) {
    require_once ROOT_PATH . '/config.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 86400");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');

define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/log_manager/');
define('LOG_MANAGER_DB', PLUGIN_BACKEND . '/log_manager.db');

// ========== ПРОВЕРКА API КЛЮЧА ==========
function validateApiKey() {
    global $db;
    
    if (!$db) {
        try {
            $db = getDB();
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database connection failed']);
            exit;
        }
    }
    
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? $_SERVER['HTTP_X_API_KEY'] ?? '';
    
    if (empty($apiKey)) {
        if (isset($_SESSION['user_id'])) {
            return true;
        }
        http_response_code(401);
        echo json_encode(['error' => 'API key required']);
        exit;
    }
    
    $stmt = $db->prepare("SELECT idHost, hostName FROM hosts WHERE hostApiKey = :key");
    $stmt->bindValue(':key', $apiKey, SQLITE3_TEXT);
    $result = $stmt->execute();
    $host = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$host) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid API key']);
        exit;
    }
    
    return true;
}

validateApiKey();

$action = $_GET['action'] ?? $_POST['action'] ?? '';
if ($action === 'get_plugin_status') {
    echo json_encode(['success' => true, 'available' => true]);
    exit;
}

// ========== ИНИЦИАЛИЗАЦИЯ БД ==========
function initLogDB() {
    $db = new SQLite3(LOG_MANAGER_DB);
    $db->exec("
        CREATE TABLE IF NOT EXISTS log_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            path TEXT NOT NULL UNIQUE,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    return $db;
}

// ========== ФУНКЦИИ ДЛЯ РАБОТЫ С ЛОГАМИ ==========
function checkFileReadable($path) {
    if (!file_exists($path)) {
        return ['readable' => false, 'error' => 'File does not exist'];
    }
    
    if (!is_readable($path)) {
        shell_exec("sudo chmod 644 " . escapeshellarg($path) . " 2>&1");
        if (!is_readable($path)) {
            return ['readable' => false, 'error' => 'File is not readable. Please check permissions.'];
        }
    }
    
    return ['readable' => true, 'error' => null];
}

function readLogFile($path, $lines = 200, $search = null) {
    $check = checkFileReadable($path);
    if (!$check['readable']) {
        return ['error' => $check['error'], 'content' => []];
    }
    
    $content = [];
    $fileSize = filesize($path);
    
    if ($fileSize > 10 * 1024 * 1024) {
        $cmd = "tail -n " . intval($lines) . " " . escapeshellarg($path) . " 2>/dev/null";
        $output = shell_exec($cmd);
        if ($output) {
            $content = explode("\n", rtrim($output));
        }
    } else {
        $handle = fopen($path, 'r');
        if ($handle) {
            $allLines = [];
            while (($line = fgets($handle)) !== false) {
                $allLines[] = rtrim($line);
            }
            fclose($handle);
            $content = array_slice($allLines, -$lines);
        }
    }
    
    if ($search && !empty($search)) {
        $search = strtolower($search);
        $content = array_filter($content, function($line) use ($search) {
            return stripos($line, $search) !== false;
        });
        $content = array_values($content);
    }
    
    return [
        'error' => null,
        'content' => $content,
        'total_lines' => count($content),
        'file_size' => $fileSize,
        'file_mtime' => filemtime($path),
        'path' => $path
    ];
}

function getLogSources() {
    $db = initLogDB();
    $result = $db->query("SELECT id, name, path, enabled, created_at, updated_at FROM log_sources ORDER BY name");
    $sources = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $row['exists'] = file_exists($row['path']);
        $row['readable'] = is_readable($row['path']);
        $row['size'] = $row['exists'] ? filesize($row['path']) : 0;
        $sources[] = $row;
    }
    $db->close();
    return $sources;
}

function addLogSource($name, $path) {
    $check = checkFileReadable($path);
    if (!$check['readable']) {
        return ['success' => false, 'error' => $check['error']];
    }
    
    $db = initLogDB();
    try {
        $stmt = $db->prepare("INSERT INTO log_sources (name, path) VALUES (:name, :path)");
        $stmt->bindValue(':name', $name, SQLITE3_TEXT);
        $stmt->bindValue(':path', $path, SQLITE3_TEXT);
        $stmt->execute();
        $id = $db->lastInsertRowID();
        $db->close();
        return ['success' => true, 'id' => $id];
    } catch (Exception $e) {
        $db->close();
        return ['success' => false, 'error' => 'Duplicate path or database error'];
    }
}

function updateLogSource($id, $name, $path) {
    $check = checkFileReadable($path);
    if (!$check['readable']) {
        return ['success' => false, 'error' => $check['error']];
    }
    
    $db = initLogDB();
    $stmt = $db->prepare("UPDATE log_sources SET name = :name, path = :path, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
    $stmt->bindValue(':name', $name, SQLITE3_TEXT);
    $stmt->bindValue(':path', $path, SQLITE3_TEXT);
    $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
    $stmt->execute();
    $db->close();
    
    return ['success' => true];
}

function deleteLogSource($id) {
    $db = initLogDB();
    $stmt = $db->prepare("DELETE FROM log_sources WHERE id = :id");
    $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
    $stmt->execute();
    $db->close();
    return ['success' => true];
}

function toggleLogSource($id, $enabled) {
    $db = initLogDB();
    $stmt = $db->prepare("UPDATE log_sources SET enabled = :enabled, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
    $stmt->bindValue(':enabled', $enabled ? 1 : 0, SQLITE3_INTEGER);
    $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
    $stmt->execute();
    $db->close();
    return ['success' => true];
}

function scanDirectoryContents($directory) {
    $items = [];
    
    $realPath = realpath($directory);
    if ($realPath === false || !is_dir($realPath) || !is_readable($realPath)) {
        return $items;
    }
    
    $directory = $realPath;
    $files = scandir($directory);
    
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        
        $fullPath = $directory . '/' . $file;
        
        if (is_dir($fullPath) && is_readable($fullPath)) {
            $items[] = [
                'name' => $file,
                'path' => $fullPath,
                'type' => 'directory',
                'size' => 0,
                'modified' => date('Y-m-d H:i:s', filemtime($fullPath))
            ];
        } elseif (is_file($fullPath) && is_readable($fullPath)) {
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            if (in_array($ext, ['log', 'txt', 'out']) || strpos($file, '.log') !== false) {
                $items[] = [
                    'name' => $file,
                    'path' => $fullPath,
                    'type' => 'file',
                    'size' => filesize($fullPath),
                    'modified' => date('Y-m-d H:i:s', filemtime($fullPath))
                ];
            }
        }
    }
    
    usort($items, function($a, $b) {
        if ($a['type'] === $b['type']) {
            return strcmp($a['name'], $b['name']);
        }
        return ($a['type'] === 'directory') ? -1 : 1;
    });
    
    return $items;
}

// ========== API ОБРАБОТЧИК ==========
$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
	case 'get_plugin_status':
		echo json_encode(['success' => true, 'available' => true]);
		break;
	
    case 'get_sources':
        echo json_encode(['success' => true, 'data' => getLogSources()]);
        break;
        
    case 'get_log':
        $id = $_GET['id'] ?? 0;
        $lines = $_GET['lines'] ?? 200;
        $search = $_GET['search'] ?? '';
        
        $db = initLogDB();
        $stmt = $db->prepare("SELECT path FROM log_sources WHERE id = :id");
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        $source = $result->fetchArray(SQLITE3_ASSOC);
        $db->close();
        
        if (!$source) {
            echo json_encode(['success' => false, 'error' => 'Log source not found']);
            break;
        }
        
        $logData = readLogFile($source['path'], $lines, $search);
        if ($logData['error']) {
            echo json_encode(['success' => false, 'error' => $logData['error']]);
        } else {
            echo json_encode([
                'success' => true,
                'content' => $logData['content'],
                'total_lines' => $logData['total_lines'],
                'file_size' => $logData['file_size'],
                'file_mtime' => $logData['file_mtime'],
                'path' => $logData['path']
            ]);
        }
        break;
        
    case 'add_source':
        $name = trim($_POST['name'] ?? '');
        $path = trim($_POST['path'] ?? '');
        
        if (empty($name)) {
            echo json_encode(['success' => false, 'error' => 'Name is required']);
        } elseif (empty($path)) {
            echo json_encode(['success' => false, 'error' => 'Path is required']);
        } else {
            $result = addLogSource($name, $path);
            echo json_encode($result);
        }
        break;
        
    case 'update_source':
        $id = $_POST['id'] ?? 0;
        $name = trim($_POST['name'] ?? '');
        $path = trim($_POST['path'] ?? '');
        
        if (empty($name) || empty($path)) {
            echo json_encode(['success' => false, 'error' => 'Name and path are required']);
        } else {
            $result = updateLogSource($id, $name, $path);
            echo json_encode($result);
        }
        break;
        
    case 'delete_source':
        $id = $_POST['id'] ?? 0;
        $result = deleteLogSource($id);
        echo json_encode($result);
        break;
        
    case 'toggle_source':
        $id = $_POST['id'] ?? 0;
        $enabled = $_POST['enabled'] ?? 1;
        $result = toggleLogSource($id, $enabled);
        echo json_encode($result);
        break;
        
    case 'scan_logs':
        $directory = $_GET['directory'] ?? '/var/log';
        if (strpos($directory, '/') !== 0) {
            $directory = '/' . $directory;
        }
        $items = scanDirectoryContents($directory);
        $currentPath = realpath($directory);
        if ($currentPath === false) {
            $currentPath = '/var/log';
        }
        echo json_encode(['success' => true, 'items' => $items, 'current_path' => $currentPath]);
        break;
        
    case 'export_log':
        $id = $_GET['id'] ?? 0;
        $format = $_GET['format'] ?? 'txt';
        
        $db = initLogDB();
        $stmt = $db->prepare("SELECT name, path FROM log_sources WHERE id = :id");
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        $source = $result->fetchArray(SQLITE3_ASSOC);
        $db->close();
        
        if (!$source) {
            echo json_encode(['success' => false, 'error' => 'Log source not found']);
            break;
        }
        
        $logData = readLogFile($source['path'], 5000);
        
        if ($format === 'json') {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="' . $source['name'] . '_' . date('Y-m-d') . '.json"');
            echo json_encode(['name' => $source['name'], 'export_date' => date('Y-m-d H:i:s'), 'content' => $logData['content']]);
        } else {
            header('Content-Type: text/plain');
            header('Content-Disposition: attachment; filename="' . $source['name'] . '_' . date('Y-m-d') . '.txt"');
            echo implode("\n", $logData['content']);
        }
        break;
		
	case 'clear_log_file':
		$id = $_POST['id'] ?? $_GET['id'] ?? 0;
		
		$db = initLogDB();
		$stmt = $db->prepare("SELECT path FROM log_sources WHERE id = :id");
		$stmt->bindValue(':id', $id, SQLITE3_INTEGER);
		$result = $stmt->execute();
		$source = $result->fetchArray(SQLITE3_ASSOC);
		$db->close();
		
		if (!$source) {
			echo json_encode(['success' => false, 'error' => 'Log source not found']);
			break;
		}
		
		if (!file_exists($source['path'])) {
			echo json_encode(['success' => false, 'error' => 'Log file does not exist']);
			break;
		}
		
		$cmd = "sudo truncate -s 0 " . escapeshellarg($source['path']) . " 2>&1";
		$output = shell_exec($cmd);
		
		if (file_exists($source['path']) && filesize($source['path']) == 0) {
			echo json_encode(['success' => true, 'message' => 'Log file cleared successfully']);
		} else {
			echo json_encode(['success' => false, 'error' => 'Failed to clear log file: ' . ($output ?: 'unknown error')]);
		}
		break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Unknown action']);
}
?>