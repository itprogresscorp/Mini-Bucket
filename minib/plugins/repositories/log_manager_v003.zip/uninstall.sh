#!/bin/bash

MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/log_manager"
MINIB_DIR="/var/www/minib/plugins/installed/log_manager"

rm -rf $ADMIN_DIR
rm -rf $MINIB_DIR
rm $MENU_DIR/log_manager.php