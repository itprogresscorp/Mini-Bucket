<?php
/**
 * Plugin Template - Main Interface File
 * 
 * This is the main entry point for the plugin UI.
 * Modify the HTML/CSS/JS in the body section to build your plugin.
 * 
 * @package Mini-B
 * @subpackage Plugin Template
 */

// ============================================
// SECTION 1: Load Initialization
// ============================================

$init = require_once __DIR__ . '/init.php';
extract($init); // $db, $host, $api_key, $js_config, $menu, $current_host_id

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mini-B - <?php echo $plugin_name; ?></title>
    
    <!-- ======================================== -->
    <!-- SECTION 2: System Libraries (Required)   -->
    <!-- ======================================== -->
    <link href="../../lib/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../css/loader.css">
    <link rel="shortcut icon" href="../../css/icon.ico" type="image/x-icon">
    
    <!-- System JS -->
    <script src="../../js/hosts_load.js"></script>
    <script src="../../js/crt_checker.js"></script>
    
    <!-- ======================================== -->
    <!-- SECTION 3: Plugin Assets                 -->
    <!-- ======================================== -->
    <link rel="stylesheet" href="plugin.css">
    
    <!-- ======================================== -->
    <!-- SECTION 4: API Configuration Injection  -->
    <!-- ======================================== -->
    <script>
    window.apiConfig = <?php echo json_encode($js_config); ?>;
    console.log('API Config loaded:', window.apiConfig);
    </script>
    
    <!-- ======================================== -->
    <!-- SECTION 5: Custom Styles (MODIFY THIS)   -->
    <!-- ======================================== -->
    <style>
        /* Add your custom styles here or use plugin.css */
        .template-container {
            padding: 20px;
        }
        
        .feature-card {
            transition: transform 0.2s;
            cursor: pointer;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>

<!-- Preloader -->
<div id="applePreloader" class="apple-preloader">
    <div class="apple-spinner"></div>
    <div class="apple-spinner-text">Loading...</div>
</div>

<!-- Top Bar -->
<div class="top-bar">
    <div class="top-bar-left">
        <h1><i class="fas fa-bucket"></i> Mini-B</h1>
    </div>
    <div class="top-bar-right">
        <div class="host-selector" style="margin-left: 20px;">
            <select id="hostSelector" style="background: rgba(255,255,255,0.9); border: 1px solid #ddd; border-radius: 20px; padding: 6px 30px 6px 15px; font-size: 14px; cursor: pointer;">
                <option value="">Loading...</option>
            </select>
        </div>
    </div>
</div>

<!-- Main Application Container -->
<div class="app-container">
    <!-- System Menu -->
    <?php echo $menu; ?>
    
    <!-- ======================================== -->
    <!-- SECTION 6: Main Content (MODIFY THIS)    -->
    <!-- ======================================== -->
    <main class="main-content">
        <!-- Alert Container for notifications -->
        <div id="alertContainer"></div>
        
        <!-- Plugin Content -->
        <div class="template-container">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget-header">
                            <h3>
                                <i class="fas fa-cube text-primary"></i> 
                                <?php echo $plugin_name; ?>
                            </h3>
                            <div>
                                <span class="badge bg-primary" id="hostStatus">
                                    <i class="fas fa-server"></i> 
                                    <?php echo $current_host_id == 1 ? 'Local Host' : 'Remote Host'; ?>
                                </span>
                            </div>
                        </div>
                        <div class="widget-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card feature-card" onclick="exampleFunction()">
                                        <div class="card-body text-center">
                                            <i class="fas fa-database fa-3x text-primary mb-3"></i>
                                            <h5>Database Example</h5>
                                            <p class="text-muted">Example of database operations</p>
                                            <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); testDatabase()">
                                                <i class="fas fa-test"></i> Test DB
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card feature-card" onclick="exampleAPICall()">
                                        <div class="card-body text-center">
                                            <i class="fas fa-cloud-upload-alt fa-3x text-success mb-3"></i>
                                            <h5>API Example</h5>
                                            <p class="text-muted">Example of remote API call</p>
                                            <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); testAPI()">
                                                <i class="fas fa-plug"></i> Test API
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Example Data Display -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <strong><i class="fas fa-terminal"></i> Output</strong>
                                        </div>
                                        <div class="card-body" id="outputArea" style="min-height: 200px; background: #f8f9fa; font-family: monospace;">
                                            <div class="text-center text-muted">
                                                <i class="fas fa-info-circle"></i> Click any button to see output here
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- ======================================== -->
<!-- SECTION 7: Modals (MODIFY AS NEEDED)     -->
<!-- ======================================== -->

<!-- Example Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-info-circle"></i> Example Modal
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>This is an example modal. Add your forms and content here.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="saveData()">Save</button>
            </div>
        </div>
    </div>
</div>

<!-- ======================================== -->
<!-- SECTION 8: JavaScript Libraries          -->
<!-- ======================================== -->
<script src="../../lib/jquery-3.6.0-master/dist/jquery.min.js"></script>
<script src="../../lib/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="../../js/loader.js"></script>
<script src="plugin.js"></script>

<!-- ======================================== -->
<!-- SECTION 9: Plugin-Specific JavaScript    -->
<!-- ======================================== -->
<script>
// ============================================
// PLUGIN INITIALIZATION
// ============================================

/**
 * Main plugin initialization function
 * Called automatically by plugin.js when plugin is ready
 */
function initPlugin() {
    console.log('Plugin Template initialized');
    showAlert('Plugin Template is ready!', 'success');
    
    // Add your initialization code here
    // - Load data from API
    // - Setup event listeners
    // - Initialize UI components
}

// ============================================
// CUSTOM FUNCTIONS (MODIFY THIS SECTION)
// ============================================

/**
 * Example function - demonstrates local database operation
 */
async function testDatabase() {
    showOutput('Testing database connection...');
    
    try {
        const result = await apiCall('example_get_data', 'GET');
        
        if (result.success) {
            showOutput('Database test successful!\n' + JSON.stringify(result.data, null, 2));
            showAlert('Database test successful!', 'success');
        } else {
            showOutput('Database test failed: ' + result.error);
            showAlert('Database test failed: ' + result.error, 'danger');
        }
    } catch (error) {
        showOutput('Error: ' + error.message);
        showAlert('Error: ' + error.message, 'danger');
    }
}

/**
 * Example function - demonstrates remote API call
 */
async function testAPI() {
    showOutput('Testing API connection...');
    
    try {
        const result = await apiCall('example_get_status', 'GET');
        
        if (result.success) {
            showOutput('API test successful!\nPlugin Status: ' + JSON.stringify(result, null, 2));
            showAlert('API test successful!', 'success');
        } else {
            showOutput('API test failed: ' + result.error);
            showAlert('API test failed: ' + result.error, 'danger');
        }
    } catch (error) {
        showOutput('Error: ' + error.message);
        showAlert('Error: ' + error.message, 'danger');
    }
}

/**
 * Example function - demonstrates form submission
 */
async function saveData() {
    const data = {
        example_field: $('#exampleField').val(),
        timestamp: new Date().toISOString()
    };
    
    const result = await apiCall('example_save_data', 'POST', data);
    
    if (result.success) {
        showAlert('Data saved successfully!', 'success');
        $('#exampleModal').modal('hide');
    } else {
        showAlert('Error saving data: ' + result.error, 'danger');
    }
}

/**
 * Display output in the output area
 * @param {string} message - Message to display
 */
function showOutput(message) {
    const outputDiv = $('#outputArea');
    const timestamp = new Date().toLocaleTimeString();
    
    outputDiv.html(`
        <div class="mb-2">
            <small class="text-muted">[${timestamp}]</small>
            <pre class="mb-0 mt-1" style="background: #fff; padding: 10px; border-radius: 5px;">${escapeHtml(message)}</pre>
        </div>
        <hr>
        <div class="text-muted text-center">
            <i class="fas fa-info-circle"></i> Click any button to see output here
        </div>
    `);
}

/**
 * Example function called from card click
 */
function exampleFunction() {
    showOutput('Card clicked! You can perform any action here.');
    showAlert('Card clicked!', 'info');
}

/**
 * Example function called from card click
 */
function exampleAPICall() {
    showOutput('API card clicked! Making API call...');
    testAPI();
}

// ============================================
// HELPER FUNCTIONS (Provided by plugin.js)
// ============================================
// 
// Available functions from plugin.js:
// 
// - apiCall(action, method, data)    : Make API calls to plugin or system
// - showAlert(message, type)          : Show notification alert
// - escapeHtml(str)                   : Escape HTML special characters
// - checkRemotePluginAvailability()   : Check if plugin exists on remote host
// - showPluginInstallModal(callback)  : Show installation modal for remote host
//
// ============================================

</script>
</body>
</html>