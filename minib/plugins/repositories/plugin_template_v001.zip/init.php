<?php
/**
 * Plugin Template - Initialization File
 * 
 * This file handles:
 * - Database connection
 * - Host detection (local/remote)
 * - API URL configuration
 * - JavaScript config injection
 * 
 * @package Mini-B
 * @subpackage Plugin Template
 */

// ============================================
// SECTION 1: System Initialization
// ============================================

// Load system config and verify authentication
require_once dirname(dirname(dirname(__FILE__))) . '/config.php';
isAuthenticated();

// Get current host ID from session (1 = localhost)
$current_host_id = $_SESSION['current_host_id'] ?? 1;

// ============================================
// SECTION 2: Database Connection
// ============================================

try {
    $db = getDB(); // System database connection
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}

// ============================================
// SECTION 3: Host Configuration
// ============================================

// Fetch host data from system database
$stmt = $db->prepare("
    SELECT idHost, hostName, hostApiKey, hostProto, hostIp, hostPort, hostApiPath 
    FROM hosts 
    WHERE idHost = :id
");
$stmt->bindValue(':id', $current_host_id, SQLITE3_INTEGER);
$result = $stmt->execute();
$host = $result->fetchArray(SQLITE3_ASSOC);

// Default values
$api_key = '';
$plugin_api_url = '';
$system_api_url = '';

if ($host) {
    $api_key = $host['hostApiKey'];
    $host_proto = $host['hostProto'];
    $host_ip = $host['hostIp'];
    $host_port = $host['hostPort'];
    $host_api_path = $host['hostApiPath'];
    
    // Build base URL
    $base_url = $host_proto . "://" . $host_ip;
    if (!empty($host_port) && $host_port != 0 && $host_port != '0') {
        $base_url .= ":" . $host_port;
    }
    
    // ============================================
    // SECTION 4: API URL Configuration (CRITICAL)
    // ============================================
    
    if ($current_host_id == 1) {
        // LOCAL HOST: Use relative paths
        $plugin_api_url = dirname($_SERVER['SCRIPT_NAME']) . '/plugin_template_api.php';
        $system_api_url = '/api/';
    } else {
        // REMOTE HOST: Use full URL with API key
        $plugin_api_url = rtrim($base_url, '/') . '/plugins/plugin_template/plugin_template_api.php';
        $system_api_url = rtrim($base_url, '/') . '/api/';
    }
}

// ============================================
// SECTION 5: JavaScript Configuration
// ============================================

$js_config = [
    'pluginApiUrl' => $plugin_api_url,      // For plugin-specific API calls
    'apiBaseUrl' => $system_api_url,        // For system API calls
    'apiKey' => $api_key,                   // Authentication key
    'isLocalhost' => ($current_host_id == 1),
    'currentHostId' => $current_host_id,
    'pluginName' => 'plugin_template'       // IMPORTANT: Must match sysname
];

// ============================================
// SECTION 6: Plugin Constants
// ============================================

// Define plugin paths (adjust as needed)
define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/log_manager/');
define('PLUGIN_DB', PLUGIN_BACKEND . '/log_manager.db');

// ============================================
// SECTION 7: Menu Integration
// ============================================

$menu = require_once dirname(dirname(dirname(__FILE__))) . '/menu.php';

// ============================================
// SECTION 8: Return Values
// ============================================

return [
    'db' => $db,
    'host' => $host,
    'api_key' => $api_key,
    'js_config' => $js_config,
    'menu' => $menu,
    'current_host_id' => $current_host_id,
    'plugin_name' => 'Plugin Template'
];
?>