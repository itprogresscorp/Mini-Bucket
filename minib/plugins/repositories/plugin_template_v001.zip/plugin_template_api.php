<?php
/**
 * Plugin Template - API File
 * 
 * Handles all AJAX requests from the frontend.
 * Add your custom actions in the switch statement below.
 * 
 * @package Mini-B
 * @subpackage Plugin Template
 */

// ============================================
// SECTION 1: Bootstrap
// ============================================

// Define root path if not defined
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));
}

// Load system config
if (file_exists(ROOT_PATH . '/config.php')) {
    require_once ROOT_PATH . '/config.php';
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// SECTION 2: CORS Headers
// ============================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 86400");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');

// ============================================
// SECTION 3: Plugin Constants
// ============================================

define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/plugin_template/');
define('PLUGIN_DB', PLUGIN_BACKEND . '/plugin_template.db');
// ============================================
// SECTION 4: API Key Validation
// ============================================

/**
 * Validate API key from request headers or session
 * @return bool True if valid
 */
function validateApiKey() {
    global $db;
    
    // Get database connection if not available
    if (!$db) {
        try {
            $db = getDB();
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database connection failed']);
            exit;
        }
    }
    
    // Get API key from various sources
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? $_SERVER['HTTP_X_API_KEY'] ?? '';
    
    // If logged in via session, allow access
    if (empty($apiKey)) {
        if (isset($_SESSION['user_id'])) {
            return true;
        }
        http_response_code(401);
        echo json_encode(['error' => 'API key required']);
        exit;
    }
    
    // Validate API key against database
    $stmt = $db->prepare("SELECT idHost, hostName FROM hosts WHERE hostApiKey = :key");
    $stmt->bindValue(':key', $apiKey, SQLITE3_TEXT);
    $result = $stmt->execute();
    $host = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$host) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid API key']);
        exit;
    }
    
    return true;
}

// Validate API key for all requests
validateApiKey();

// ============================================
// SECTION 5: Database Initialization
// ============================================

/**
 * Initialize plugin database (SQLite)
 * @return SQLite3 Database connection
 */
function initPluginDB() {
    $db = new SQLite3(PLUGIN_DB);
    
    // Create example table
    $db->exec("
        CREATE TABLE IF NOT EXISTS example_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    
    return $db;
}

// ============================================
// SECTION 6: Plugin Functions (MODIFY THIS)
// ============================================

/**
 * Example function - get data from database
 * @return array Example data
 */
function getExampleData() {
    $db = initPluginDB();
    $result = $db->query("SELECT id, data, created_at FROM example_data ORDER BY id DESC LIMIT 10");
    
    $items = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $items[] = $row;
    }
    
    $db->close();
    return $items;
}

/**
 * Example function - save data to database
 * @param string $data Data to save
 * @return array Result
 */
function saveExampleData($data) {
    $db = initPluginDB();
    $stmt = $db->prepare("INSERT INTO example_data (data) VALUES (:data)");
    $stmt->bindValue(':data', $data, SQLITE3_TEXT);
    $result = $stmt->execute();
    $id = $db->lastInsertRowID();
    $db->close();
    
    return ['success' => true, 'id' => $id];
}

/**
 * Example function - get plugin status (required for remote installation)
 * @return array Status
 */
function getPluginStatus() {
    return [
        'success' => true,
        'available' => true,
        'version' => '1.0.0',
        'name' => 'Plugin Template'
    ];
}

// ============================================
// SECTION 7: API Router (MODIFY THIS)
// ============================================

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    // ========================================
    // REQUIRED ACTIONS (Do not remove)
    // ========================================
    
    case 'get_plugin_status':
        echo json_encode(getPluginStatus());
        break;
    
    // ========================================
    // EXAMPLE ACTIONS (Modify as needed)
    // ========================================
    
    case 'example_get_data':
        $data = getExampleData();
        echo json_encode(['success' => true, 'data' => $data]);
        break;
    
    case 'example_get_status':
        echo json_encode([
            'success' => true,
            'status' => 'online',
            'timestamp' => date('Y-m-d H:i:s'),
            'host' => $_SERVER['HTTP_HOST'] ?? 'unknown'
        ]);
        break;
    
    case 'example_save_data':
        $data = $_POST['example_field'] ?? '';
        if (empty($data)) {
            echo json_encode(['success' => false, 'error' => 'Data is required']);
        } else {
            $result = saveExampleData($data);
            echo json_encode($result);
        }
        break;
    
    // ========================================
    // DEFAULT: Unknown action
    // ========================================
    
    default:
        echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
}
?>