#!/bin/bash

# Пути
MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/plugin_template"
MINIB_DIR="/var/www/minib/plugins/installed/plugin_template"

# Создаем папки
mkdir -p $ADMIN_DIR
mkdir -p $MINIB_DIR

# Назначаем владельца и права
chown -R www-data:www-data $ADMIN_DIR
chown -R www-data:www-data $MINIB_DIR
chmod -R 755 $ADMIN_DIR
chmod -R 755 $MINIB_DIR
chmod +x uninstall.sh

# Копируем файлы в admin
cp -p plugin_template.php $ADMIN_DIR/
cp -p plugin_template_api.php $ADMIN_DIR/
cp -p init.php $ADMIN_DIR/
cp -p plugin.css $ADMIN_DIR/
cp -p plugin.js $ADMIN_DIR/
cp -p menu/plugin_template.php $MENU_DIR/

# Копируем файлы в minib
cp -p install.php $MINIB_DIR/
cp -p info.json $MINIB_DIR/
cp -p uninstall.sh $MINIB_DIR/

# Запускаем установку БД
php $MINIB_DIR/install.php
chown www-data:www-data $MINIB_DIR/plugin_template.db
chmod 755 $MINIB_DIR/plugin_template.db

# Удаляем папку extract если есть
rm -rf /var/www/minib/plugins/extract/plugin_template*
