<?php
/*
 * Log Manager Plugin for Mini-Bucket NAS Control Panel
 */

define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));

if (file_exists(ROOT_PATH . '/config.php')) {
    require_once ROOT_PATH . '/config.php';
}

define('PLUGIN_BACKEND', '/var/www/minib/plugins/installed/plugin_template/');
$dbPath = PLUGIN_BACKEND . '/plugin_template.db';

/*
try {
    $db = new SQLite3($dbPath);
    
    // Таблица для хранения источников логов
    $db->exec("
        CREATE TABLE IF NOT EXISTS log_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            path TEXT NOT NULL UNIQUE,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    
    // Таблица для кэша логов (опционально)
    $db->exec("
        CREATE TABLE IF NOT EXISTS log_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id INTEGER,
            content TEXT,
            line_count INTEGER,
            file_size INTEGER,
            file_mtime INTEGER,
            cached_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (source_id) REFERENCES log_sources(id) ON DELETE CASCADE
        )
    ");
    
    // Добавляем стандартные логи, если таблица пуста
    $check = $db->querySingle("SELECT COUNT(*) FROM log_sources");
    if ($check == 0) {
        $defaultLogs = [
            ['System Log', '/var/log/syslog'],
            ['Auth Log', '/var/log/auth.log'],
            ['MySQL Error', '/var/log/mysql/error.log'],
			['Mini-B WEB Error', '/var/www/minib/logs/web/admin_error.log'],
			['Mini-B WEB Access', '/var/www/minib/logs/web/admin_access.log'],
			['Mini-B API Inspector', '/var/www/minib/logs/api_inspector.log'],
			['Mini-B API Auto Rotation', '/var/www/minib/logs/auto_rotation.log'],
			['Mini-B API KEY Rotation', '/var/www/minib/logs/key_rotation.log'],
			['Mini-B Cron API Auto Rotation', '/var/www/minib/logs/cron_autorotate_key.log'],
			['Mini-B Cron API KEY Rotation', '/var/www/minib/logs/cron_key_rotation.log'],
			['Mini-B Disk Manager', '/var/www/minib/logs/disk_manager.log'],
			['Mini-B Download', '/var/www/minib/logs/download_log.txt'],
			['Mini-B Last Update', '/var/www/minib/logs/last_update.txt'],
			['Mini-B Mount Master', '/var/www/minib/logs/mount_master.log'],
        ];
        
        $stmt = $db->prepare("INSERT INTO log_sources (name, path) VALUES (:name, :path)");
        foreach ($defaultLogs as $log) {
            if (file_exists($log[1])) {
                $stmt->bindValue(':name', $log[0], SQLITE3_TEXT);
                $stmt->bindValue(':path', $log[1], SQLITE3_TEXT);
                $stmt->execute();
                $stmt->reset();
            }
        }
    }
    
    $db->close();
    
    echo "Database created successfully at: " . $dbPath . "\n";
    
} catch (Exception $e) {
    echo "Error creating database: " . $e->getMessage() . "\n";
}
*/
?>