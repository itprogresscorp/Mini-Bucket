/**
 * Plugin Template - Universal JavaScript Core
 * 
 * This file provides all the core functionality needed for any Mini-B plugin:
 * - API communication (local & remote)
 * - Remote plugin installation
 * - Alert notifications
 * - HTML escaping
 * - Multi-host support
 * 
 * @package Mini-B Plugin System
 * @version 1.0.0
 */

// ============================================
// SECTION 1: GLOBAL VARIABLES
// ============================================

/**
 * Flag indicating if remote plugin is available
 * @var {boolean}
 */
let remotePluginAvailable = true;

/**
 * Pending action to execute after plugin installation
 * @var {Function|null}
 */
let pendingAction = null;

/**
 * Current plugin name (set by main plugin file)
 * @var {string}
 */
window.pluginName = window.pluginName || 'plugin_template';

// ============================================
// SECTION 2: UNIVERSAL API CALL FUNCTION
// ============================================

/**
 * Universal API caller that automatically routes requests to the correct endpoint
 * 
 * System actions (go to api/plugins_api.php):
 *   - send_plugin_to_remote
 *   - check_remote_plugin
 *   - get_repository
 *   - install_from_repository
 *   - upload_plugin
 *   - delete_repository_zip
 *   - get_plugin_status
 *   - install_plugin
 * 
 * Plugin actions (go to plugin's own API):
 *   - All other actions (get_sources, get_log, etc.)
 * 
 * @param {string} action - API action name
 * @param {string} method - HTTP method (GET, POST, etc.)
 * @param {Object|null} data - Request data (for POST and GET params)
 * @returns {Promise<Object>} API response
 * 
 * @example
 * // GET request
 * const result = await apiCall('get_sources', 'GET');
 * 
 * @example
 * // POST request
 * const result = await apiCall('add_source', 'POST', { name: 'My Log', path: '/var/log/my.log' });
 */
async function apiCall(action, method = 'GET', data = null) {
    // ========================================
    // Step 1: Determine which API endpoint to use
    // ========================================
    
    // List of actions that require system API (plugins_api.php)
    const systemActions = [
        'send_plugin_to_remote', 
        'check_remote_plugin', 
        'get_repository', 
        'install_from_repository', 
        'upload_plugin', 
        'delete_repository_zip',
        'get_plugin_status', 
        'install_plugin'
    ];
    
    let baseUrl;
    
    if (systemActions.includes(action)) {
        // System actions use the central plugins API
        baseUrl = window.apiConfig.apiBaseUrl + 'plugins_api.php';
        console.log(`[API] Using system API for action: ${action}`, baseUrl);
    } else {
        // Plugin actions use the plugin's own API
        baseUrl = window.apiConfig.pluginApiUrl;
        console.log(`[API] Using plugin API for action: ${action}`, baseUrl);
    }
    
    // ========================================
    // Step 2: Build the full URL
    // ========================================
    
    let url;
    if (method === 'GET' && data) {
        // Append data as query parameters for GET requests
        const params = new URLSearchParams(data);
        url = `${baseUrl}?action=${action}&${params.toString()}`;
    } else {
        url = `${baseUrl}?action=${action}`;
    }
    
    // ========================================
    // Step 3: Configure request options
    // ========================================
    
    const options = {
        method: method,
        headers: {
            'X-API-Key': window.apiConfig.apiKey || '',
            'Accept': 'application/json'
        }
    };
    
    // Add body for POST requests
    if (method === 'POST' && data) {
        options.headers['Content-Type'] = 'application/x-www-form-urlencoded';
        options.body = new URLSearchParams(data);
    }
    
    // ========================================
    // Step 4: Execute the request
    // ========================================
    
    try {
        console.log(`[API] Request: ${method} ${url}`, options.body || '');
        
        const response = await fetch(url, options);
        
        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            const result = await response.json();
            console.log(`[API] Response for ${action}:`, result);
            return result;
        } else {
            // Handle non-JSON responses
            const text = await response.text();
            console.error(`[API] Non-JSON response for ${action}:`, text);
            return { 
                success: false, 
                error: 'Invalid API response format',
                raw_response: text.substring(0, 200) 
            };
        }
    } catch (error) {
        console.error(`[API] Error for ${action}:`, error);
        return { 
            success: false, 
            error: error.message || 'Network error',
            network_error: true
        };
    }
}

// ============================================
// SECTION 3: REMOTE PLUGIN MANAGEMENT
// ============================================

/**
 * Check if plugin is available on remote server
 * 
 * This function tests whether the plugin's API is accessible on the remote host.
 * It's automatically called during initialization.
 * 
 * @returns {Promise<boolean>} True if plugin is available
 */
async function checkRemotePluginAvailability() {
    // Localhost always has the plugin
    if (window.apiConfig.isLocalhost) {
        console.log('[Plugin] Running on localhost, plugin available');
        return true;
    }
    
    try {
        // Build URL for plugin status check on remote server
        // Format: /api/../plugins/plugin_name/plugin_name_api.php
        const pluginApiUrl = `${window.apiConfig.apiBaseUrl}../plugins/${window.pluginName}/${window.pluginName}_api.php`;
        
        console.log(`[Plugin] Checking remote plugin availability at: ${pluginApiUrl}`);
        
        const response = await fetch(`${pluginApiUrl}?action=get_plugin_status`, {
            method: 'GET',
            headers: { 
                'X-API-Key': window.apiConfig.apiKey || '',
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) {
            console.log(`[Plugin] Remote plugin check failed with status: ${response.status}`);
            return false;
        }
        
        const result = await response.json();
        const available = result.success === true;
        
        console.log(`[Plugin] Remote plugin available: ${available}`);
        return available;
        
    } catch (error) {
        console.error('[Plugin] Remote plugin check error:', error);
        return false;
    }
}

/**
 * Install plugin on remote server
 * 
 * This function:
 * 1. Finds the plugin ZIP in local repository
 * 2. Downloads the ZIP file
 * 3. Uploads and installs it on remote server
 * 
 * @returns {Promise<void>}
 */
async function installRemotePlugin() {
    const installBtn = $('#confirmInstallBtn');
    const progressDiv = $('#installProgress');
    const progressBar = $('.progress-bar');
    const statusText = $('#installStatus');
    
    // Disable button and show progress
    installBtn.prop('disabled', true);
    installBtn.html('<span class="loading-spinner-sm"></span> Installing...');
    progressDiv.show();
    
    try {
        // ========================================
        // Step 1: Get repository list from local server
        // ========================================
        
        statusText.text('Searching for plugin package...');
        progressBar.css('width', '30%');
        
        const repoResponse = await fetch('/api/plugins_api.php?action=get_repository', {
            headers: { 
                'X-API-Key': window.apiConfig.apiKey || '',
                'Accept': 'application/json'
            }
        });
        
        if (!repoResponse.ok) {
            throw new Error(`HTTP ${repoResponse.status}: Failed to get repository list`);
        }
        
        const repoData = await repoResponse.json();
        
        if (!repoData.success || !repoData.data) {
            throw new Error('Failed to get repository list: ' + (repoData.error || 'Unknown error'));
        }
        
        console.log('[Install] Local repository plugins:', repoData.data);
        
        // ========================================
        // Step 2: Find the plugin in repository
        // ========================================
        
        let pluginZip = null;
        for (const plugin of repoData.data) {
            if (plugin.info && plugin.info.sysname === window.pluginName) {
                pluginZip = plugin;
                break;
            }
        }
        
        if (!pluginZip) {
            throw new Error(`Plugin "${window.pluginName}" not found in local repository. Please upload the ZIP file to plugins/repositories/`);
        }
        
        statusText.text(`Found: ${pluginZip.filename}`);
        progressBar.css('width', '50%');
        
        // ========================================
        // Step 3: Download the ZIP file
        // ========================================
        
        statusText.text('Downloading plugin package...');
        
        const zipResponse = await fetch(`/api/plugins_api.php?action=download_plugin_zip&filename=${encodeURIComponent(pluginZip.filename)}`, {
            headers: { 
                'X-API-Key': window.apiConfig.apiKey || ''
            }
        });
        
        if (!zipResponse.ok) {
            throw new Error(`Failed to download plugin ZIP: HTTP ${zipResponse.status}`);
        }
        
        const zipBlob = await zipResponse.blob();
        
        // ========================================
        // Step 4: Upload and install on remote server
        // ========================================
        
        const formData = new FormData();
        formData.append('plugin_file', zipBlob, pluginZip.filename);
        
        statusText.text('Installing on remote server...');
        progressBar.css('width', '75%');
        
        const installUrl = `${window.apiConfig.apiBaseUrl}plugin_remote_installer.php?action=install_plugin`;
        
        const installResponse = await fetch(installUrl, {
            method: 'POST',
            headers: {
                'X-API-Key': window.apiConfig.apiKey || ''
            },
            body: formData
        });
        
        const installResult = await installResponse.json();
        
        if (!installResult.success) {
            throw new Error(installResult.error || 'Installation failed on remote server');
        }
        
        // ========================================
        // Step 5: Success!
        // ========================================
        
        statusText.text('Installation completed!');
        progressBar.css('width', '100%');
        
        showAlert('Plugin successfully installed on remote server!', 'success');
        
        // Reload page after installation
        setTimeout(() => {
            $('#pluginInstallModal').modal('hide');
            location.reload();
        }, 1500);
        
    } catch (error) {
        console.error('[Install] Error:', error);
        
        // Show error message
        showAlert('Installation failed: ' + error.message, 'danger');
        
        statusText.html(`<span class="text-danger">Error: ${escapeHtml(error.message)}</span>`);
        
        // Reset button
        installBtn.prop('disabled', false);
        installBtn.html('<i class="fas fa-download"></i> Try Again');
        progressDiv.hide();
    }
}

/**
 * Show modal dialog for plugin installation
 * 
 * This modal appears when the plugin is not installed on a remote host
 * and offers to automatically install it.
 * 
 * @param {Function} callback - Optional callback after installation
 */
function showPluginInstallModal(callback) {
    // Store callback for after installation
    pendingAction = callback;
    
    // Create modal HTML dynamically
    const modalHtml = `
        <div class="modal fade" id="pluginInstallModal" tabindex="-1" data-bs-backdrop="static">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title">
                            <i class="fas fa-puzzle-piece"></i> Plugin Not Installed
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-4">
                            <i class="fas fa-puzzle-piece fa-4x text-muted mb-3"></i>
                            <h6>Plugin is not installed on the remote server</h6>
                            <p class="text-muted">This plugin is required to use this feature on the remote host.</p>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>What will happen?</strong><br>
                            The plugin will be automatically installed on the remote server.
                            You don't need to do anything manually.
                        </div>
                        <div id="installProgress" style="display: none;">
                            <div class="progress mb-2">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                     style="width: 0%">0%</div>
                            </div>
                            <p class="text-center small text-muted" id="installStatus">Preparing installation...</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button type="button" class="btn btn-primary" id="confirmInstallBtn">
                            <i class="fas fa-download"></i> Install Plugin
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if present
    $('#pluginInstallModal').remove();
    $('body').append(modalHtml);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('pluginInstallModal'));
    modal.show();
    
    // Setup install button handler
    $('#confirmInstallBtn').off('click').on('click', async function() {
        await installRemotePlugin();
    });
}

// ============================================
// SECTION 4: UI HELPER FUNCTIONS
// ============================================

/**
 * Show a temporary alert notification
 * 
 * @param {string} message - Alert message
 * @param {string} type - Alert type: 'success', 'danger', 'warning', 'info'
 * 
 * @example
 * showAlert('Data saved successfully!', 'success');
 * showAlert('Something went wrong!', 'danger');
 */
function showAlert(message, type = 'success') {
    // Map type to icon
    const iconMap = {
        'success': 'check-circle',
        'danger': 'exclamation-triangle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    
    const icon = iconMap[type] || 'info-circle';
    
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert" style="position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
            <i class="fas fa-${icon}"></i> 
            ${escapeHtml(message)}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    $('#alertContainer').append(alertHtml);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        $('.alert').fadeOut(500, function() { 
            $(this).remove(); 
        });
    }, 5000);
}

/**
 * Escape HTML special characters to prevent XSS attacks
 * 
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 * 
 * @example
 * const safe = escapeHtml('<script>alert("xss")</script>');
 * // safe = '&lt;script&gt;alert("xss")&lt;/script&gt;'
 */
function escapeHtml(str) {
    if (!str) return '';
    if (typeof str !== 'string') str = String(str);
    
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * Format file size from bytes to human-readable format
 * 
 * @param {number} bytes - Size in bytes
 * @returns {string} Formatted size (e.g., "1.5 KB", "2.3 MB")
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    if (!bytes) return '0 B';
    
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * Format timestamp to readable date/time
 * 
 * @param {number|string} timestamp - Unix timestamp or date string
 * @returns {string} Formatted date string
 */
function formatDate(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = typeof timestamp === 'number' 
        ? new Date(timestamp * 1000) 
        : new Date(timestamp);
    
    return date.toLocaleString();
}

/**
 * Highlight search terms in text
 * 
 * @param {string} text - Original text
 * @param {string} searchTerm - Search term to highlight
 * @returns {string} HTML with highlighted spans
 */
function highlightSearch(text, searchTerm) {
    if (!searchTerm || !text) return escapeHtml(text);
    
    const escapedText = escapeHtml(text);
    const escapedSearch = escapeHtml(searchTerm);
    const regex = new RegExp(`(${escapedSearch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    
    return escapedText.replace(regex, '<span class="search-highlight">$1</span>');
}

// ============================================
// SECTION 5: PLUGIN INITIALIZATION
// ============================================

/**
 * Initialize the plugin system
 * 
 * This runs automatically when the page loads and:
 * 1. Waits for API config to be available
 * 2. Checks if plugin exists on remote host
 * 3. Shows install modal if needed
 * 4. Calls plugin-specific initPlugin() function
 */
$(document).ready(async function() {
    console.log('[Plugin] Initializing plugin system...');
    console.log('[Plugin] API Config:', window.apiConfig);
    
    // Check if API config is loaded
    if (window.apiConfig && window.apiConfig.apiBaseUrl) {
        console.log('[Plugin] API Base URL:', window.apiConfig.apiBaseUrl);
        console.log('[Plugin] Plugin API URL:', window.apiConfig.pluginApiUrl);
        console.log('[Plugin] Is Localhost:', window.apiConfig.isLocalhost);
        
        // Check remote plugin availability
        const pluginAvailable = await checkRemotePluginAvailability();
        remotePluginAvailable = pluginAvailable;
        
        // If remote host and plugin not available, show install modal
        if (!pluginAvailable && !window.apiConfig.isLocalhost) {
            console.log('[Plugin] Plugin not available on remote host, showing install modal');
            showPluginInstallModal(() => {
                // Reload after installation
                location.reload();
            });
        } else {
            console.log('[Plugin] Plugin available, calling initPlugin()');
            
            // Call plugin-specific initialization if it exists
            if (typeof initPlugin === 'function') {
                initPlugin();
            } else {
                console.warn('[Plugin] initPlugin() function not defined');
                // Show default message
                showAlert('Plugin loaded. Define initPlugin() function to add custom behavior.', 'info');
            }
        }
    } else {
        console.error('[Plugin] API Config not loaded properly!');
        console.error('[Plugin] window.apiConfig:', window.apiConfig);
        
        // Show error in UI
        $('#alertContainer').append(`
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle"></i> 
                API Configuration Error! Please check that the plugin is properly installed.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);
    }
    
    // Hide preloader after a short delay
    setTimeout(function() {
        if ($('#applePreloader').length) {
            $('#applePreloader').fadeOut(500);
        }
    }, 500);
});

/**
 * Clean up on page unload
 */
$(window).on('beforeunload', function() {
    console.log('[Plugin] Cleaning up...');
    
    // Add any cleanup code here
    // For example: clear intervals, close connections, etc.
});

// ============================================
// SECTION 6: EXPORTS (for use in other files)
// ============================================

// Make functions globally available
window.apiCall = apiCall;
window.showAlert = showAlert;
window.escapeHtml = escapeHtml;
window.formatFileSize = formatFileSize;
window.formatDate = formatDate;
window.highlightSearch = highlightSearch;
window.checkRemotePluginAvailability = checkRemotePluginAvailability;
window.showPluginInstallModal = showPluginInstallModal;
window.installRemotePlugin = installRemotePlugin;
window.remotePluginAvailable = remotePluginAvailable;

console.log('[Plugin] Core functions loaded and ready');