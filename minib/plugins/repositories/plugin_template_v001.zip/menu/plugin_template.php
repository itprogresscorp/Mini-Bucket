<?php return array (
  'enabled' => false,
  'group' => 'tools',
  'group_title' => 'tools',
  'title' => 'Plugin Template',
  'url' => 'plugins/plugin_template/plugin_template.php',
  'icon' => 'fas fa-file',
);