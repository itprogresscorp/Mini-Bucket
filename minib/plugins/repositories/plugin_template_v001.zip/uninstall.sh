#!/bin/bash

MENU_DIR="/var/www/html/admin/plugins/menu"
ADMIN_DIR="/var/www/html/admin/plugins/plugin_template"
MINIB_DIR="/var/www/minib/plugins/installed/plugin_template"

rm -rf $ADMIN_DIR
rm -rf $MINIB_DIR
rm $MENU_DIR/plugin_template.php